package com.mahava.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mahava.app.R
import com.mahava.app.data.db.PeriodEventEntity
import com.mahava.app.data.db.UserProfileEntity
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import com.mahava.app.util.JalaliDate
import com.mahava.app.util.PersianDigits
import java.time.LocalDate

@Composable
fun OnboardingFlow(vm: AppViewModel, onFinished: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var goal by remember { mutableStateOf("track_period") }
    var lastStart by remember { mutableStateOf(vm.today().minusDays(14)) }
    var cycleLen by remember { mutableIntStateOf(28) }
    var bleedLen by remember { mutableIntStateOf(5) }
    var cycleUnknown by remember { mutableStateOf(false) }
    var bleedUnknown by remember { mutableStateOf(false) }
    var regular by remember { mutableStateOf<Boolean?>(true) }
    var hormonal by remember { mutableStateOf(false) }
    var postpartum by remember { mutableStateOf(false) }
    var peri by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<LocalDate>()) }

    Column(Modifier.fillMaxSize().background(MahavaBackground)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(4) { i ->
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (i == step) MahavaPrimary else MahavaBorder))
            }
        }
        when (step) {
            0 -> WelcomeGoalStep(goal = goal, onGoal = { goal = it }, onNext = { step = 1 })
            1 -> CycleInfoStep(
                lastStart, { lastStart = it }, cycleLen, { cycleLen = it }, bleedLen, { bleedLen = it },
                cycleUnknown, { cycleUnknown = it }, bleedUnknown, { bleedUnknown = it },
                onNext = { step = 2 }, onBack = { step = 0 }
            )
            2 -> ConditionsStep(
                regular, { regular = it }, hormonal, { hormonal = it }, postpartum, { postpartum = it }, peri, { peri = it },
                onNext = { step = 3 }, onSkip = { step = 3 }, onBack = { step = 1 }
            )
            else -> HistoryStep(
                history = history,
                onAdd = { d -> if (d !in history && !d.isAfter(vm.today())) history = (history + d).sortedDescending() },
                onRemove = { d -> history = history - d },
                onBack = { step = 2 },
                onEnter = {
                    val now = System.currentTimeMillis()
                    val profile = UserProfileEntity(
                        onboardingDone = true,
                        goal = goal,
                        lastPeriodStartEpochDay = lastStart.toEpochDay(),
                        typicalCycleLength = if (cycleUnknown) null else cycleLen,
                        typicalBleedLength = if (bleedUnknown) null else bleedLen,
                        cycleLengthUnknown = cycleUnknown,
                        bleedLengthUnknown = bleedUnknown,
                        regularCycles = regular,
                        hormonalContraception = hormonal,
                        postpartumOrBreastfeeding = postpartum,
                        perimenopause = peri,
                        fertilityTrackingEnabled = goal == "ttc",
                        createdAt = now,
                        updatedAt = now
                    )
                    vm.saveOnboarding(profile)
                    history.forEach { d ->
                        vm.savePeriod(d, null, false)
                    }
                    onFinished()
                }
            )
        }
    }
}

@Composable
private fun WelcomeGoalStep(goal: String, onGoal: (String) -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("خوش آمدی", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Illustration(R.drawable.ill_welcome_woman, Modifier.height(180.dp))
        Text("بدنت را بهتر بشناس", style = MaterialTheme.typography.headlineLarge)
        QuietInfo("همراه روزانه چرخه تو")
        Spacer(Modifier.height(12.dp))
        MahavaCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MahavaIcon(R.drawable.ic_lock)
                Spacer(Modifier.width(8.dp))
                Text("داده‌ها روی گوشی می‌مانند؛ بدون حساب و اینترنت در زمان استفاده.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(16.dp))
        SectionLabel("هدف اصلی تو از استفاده چیست؟")
        GoalRow("track_period", goal, "پیگیری پریود", R.drawable.ic_droplet, MahavaMenstruation, onGoal)
        GoalRow("body_awareness", goal, "شناخت بدن", R.drawable.ic_leaf, MahavaFertility, onGoal)
        GoalRow("ttc", goal, "اقدام برای بارداری", R.drawable.ic_heart, MahavaMenstruation, onGoal)
        Spacer(Modifier.height(20.dp))
        PrimaryButton("شروع کنیم", onClick = onNext)
    }
}

@Composable
private fun GoalRow(id: String, selected: String, label: String, icon: Int, tint: Color, onGoal: (String) -> Unit) {
    val sel = id == selected
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp))
            .border(1.dp, if (sel) MahavaPrimary else MahavaBorder, RoundedCornerShape(16.dp))
            .background(if (sel) MahavaPrimarySoft else MahavaSurface)
            .clickable { onGoal(id) }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MahavaIcon(icon, tint)
        Spacer(Modifier.width(12.dp))
        Text(label, modifier = Modifier.weight(1f))
        RadioButton(selected = sel, onClick = { onGoal(id) })
    }
}

@Composable
private fun CycleInfoStep(
    lastStart: LocalDate, onLast: (LocalDate) -> Unit,
    cycleLen: Int, onCycle: (Int) -> Unit,
    bleedLen: Int, onBleed: (Int) -> Unit,
    cycleUnknown: Boolean, onCycleUnknown: (Boolean) -> Unit,
    bleedUnknown: Boolean, onBleedUnknown: (Boolean) -> Unit,
    onNext: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("اطلاعات چرخه", onBack = onBack)
        SectionLabel("اولین روز آخرین پریود")
        MahavaCard {
            Text(JalaliDate.from(lastStart).formatFa())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceChipPill("۳ روز قبل", false, { onLast(lastStart.minusDays(3)) })
                ChoiceChipPill("دیروز", false, { onLast(LocalDate.now().minusDays(1).coerceAtMost(LocalDate.now())) })
                ChoiceChipPill("امروز", false, { onLast(LocalDate.now()) })
            }
            QuietInfo("تاریخ آینده مجاز نیست.")
        }
        Spacer(Modifier.height(12.dp))
        SectionLabel("طول چرخه")
        StepperRow(cycleLen, 15, 60, "روز", !cycleUnknown) { onCycle(it) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(cycleUnknown, onCycleUnknown); Text("نمی‌دانم")
        }
        SectionLabel("مدت خون‌ریزی")
        StepperRow(bleedLen, 1, 15, "روز", !bleedUnknown) { onBleed(it) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(bleedUnknown, onBleedUnknown); Text("نمی‌دانم")
        }
        QuietInfo("مقدار پیش‌فرض بدون تأیید تو به‌عنوان واقعیت ذخیره نمی‌شود؛ با «نمی‌دانم» تخمین قطعی ساخته نمی‌شود.")
        Spacer(Modifier.height(16.dp))
        PrimaryButton("ادامه", onClick = onNext)
    }
}

@Composable
private fun StepperRow(value: Int, min: Int, max: Int, unit: String, enabled: Boolean, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = { if (enabled && value > min) onChange(value - 1) }, enabled = enabled) { MahavaIcon(R.drawable.ic_minus) }
        Text("${PersianDigits.toPersian(value)} $unit", style = MaterialTheme.typography.titleLarge)
        IconButton(onClick = { if (enabled && value < max) onChange(value + 1) }, enabled = enabled) { MahavaIcon(R.drawable.ic_plus) }
    }
}

@Composable
private fun ConditionsStep(
    regular: Boolean?, onRegular: (Boolean) -> Unit,
    hormonal: Boolean, onHormonal: (Boolean) -> Unit,
    postpartum: Boolean, onPost: (Boolean) -> Unit,
    peri: Boolean, onPeri: (Boolean) -> Unit,
    onNext: () -> Unit, onSkip: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("شرایط بدن من", onBack = onBack)
        SectionLabel("وضعیت چرخه قاعدگی")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ConditionCard("منظم", regular == true, R.drawable.ic_calendar, Modifier.weight(1f)) { onRegular(true) }
            ConditionCard("نامنظم", regular == false, R.drawable.ic_cycle, Modifier.weight(1f)) { onRegular(false) }
        }
        Spacer(Modifier.height(12.dp))
        SectionLabel("سایر شرایط (اختیاری)")
        ToggleLine("روش هورمونی جلوگیری", R.drawable.ic_pill, hormonal, onHormonal)
        ToggleLine("شیردهی / زایمان اخیر", R.drawable.ic_heart, postpartum, onPost)
        ToggleLine("نزدیک یائسگی", R.drawable.ic_info, peri, onPeri)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("ادامه", onClick = onNext)
        Spacer(Modifier.height(8.dp))
        SecondaryButton("فعلاً رد می‌کنم", onClick = onSkip)
    }
}

@Composable private fun ConditionCard(title: String, selected: Boolean, icon: Int, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).border(1.dp, if (selected) MahavaPrimary else MahavaBorder, RoundedCornerShape(16.dp))
            .background(if (selected) MahavaPrimarySoft else MahavaSurface).clickable(onClick = onClick).padding(16.dp).heightIn(min = 96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MahavaIcon(icon); Spacer(Modifier.height(8.dp)); Text(title)
    }
}

@Composable private fun ToggleLine(label: String, icon: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        MahavaIcon(icon); Spacer(Modifier.width(10.dp)); Text(label, Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable
private fun HistoryStep(
    history: List<LocalDate>, onAdd: (LocalDate) -> Unit, onRemove: (LocalDate) -> Unit,
    onBack: () -> Unit, onEnter: () -> Unit
) {
    var pickOffset by remember { mutableIntStateOf(28) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("سابقه پریود", onBack = onBack)
        QuietInfo("شروع پریودهای قبلی (اختیاری)")
        history.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(JalaliDate.from(d).formatFa(), Modifier.weight(1f))
                IconButton(onClick = { onRemove(d) }) { MahavaIcon(R.drawable.ic_trash, MahavaDanger) }
            }
        }
        SecondaryButton("+ افزودن تاریخ (حدود ${PersianDigits.toPersian(pickOffset)} روز قبل)") {
            onAdd(LocalDate.now().minusDays(pickOffset.toLong()))
            pickOffset += 28
        }
        QuietInfo("اگر یادت نیست، بعداً ثبت کن.")
        Spacer(Modifier.height(20.dp))
        PrimaryButton("ورود به برنامه", onClick = onEnter)
    }
}
