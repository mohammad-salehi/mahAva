package com.mahava.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mahava.app.R
import com.mahava.app.data.db.DailyLogEntity
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import com.mahava.app.util.JalaliDate
import com.mahava.app.util.PersianDigits
import java.time.LocalDate

@Composable
fun LogHubScreen(vm: AppViewModel, onDaily: () -> Unit, onPeriod: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("ثبت", onSettings = onSettings)
        PrimaryButton("ثبت حال امروز", onClick = onDaily)
        Spacer(Modifier.height(12.dp))
        SecondaryButton("ثبت پریود", onClick = onPeriod)
        Spacer(Modifier.height(12.dp))
        QuietInfo("پیش‌فرض‌ها به‌صورت علامت واقعی ذخیره نمی‌شوند تا خودت انتخاب کنی.")
    }
}

@Composable
fun DailyLogScreen(vm: AppViewModel, day: LocalDate, onBack: () -> Unit) {
    val existing = vm.logFor(day)
    var bleeding by remember { mutableStateOf(existing?.bleeding) }
    var mood by remember { mutableStateOf(existing?.moods?.split(',')?.firstOrNull()) }
    var energy by remember { mutableStateOf(existing?.energy) }
    var symptoms by remember { mutableStateOf(existing?.physicalSymptoms?.split(',')?.filter { it.isNotBlank() }?.toSet() ?: emptySet()) }
    var noSymptoms by remember { mutableStateOf(existing?.noSymptoms == true) }
    var pain by remember { mutableIntStateOf(existing?.painScore ?: -1) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var showExtra by remember { mutableStateOf(false) }
    var discharge by remember { mutableStateOf(existing?.discharge) }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("ثبت حال امروز", onBack = onBack)
        Text("${JalaliDate.weekdayNameFa(day)}، ${JalaliDate.from(day).formatFa()}", color = MahavaTextSecondary)
        Spacer(Modifier.height(12.dp))
        SectionLabel("۱) خون‌ریزی داری؟")
        FlowChoices(
            listOf("none" to "ندارم", "spotting" to "لکه‌بینی", "light" to "کم", "medium" to "متوسط", "heavy" to "زیاد"),
            bleeding
        ) { bleeding = it; noSymptoms = false }

        SectionLabel("۲) حالت چطور است؟")
        FlowChoices(
            listOf("sad" to "غمگین", "anxious" to "مضطرب", "calm" to "آرام", "happy" to "خوشحال", "irritable" to "تحریک‌پذیر"),
            mood
        ) { mood = it; noSymptoms = false }

        SectionLabel("۳) علامتی داری؟")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceChipPill("هیچ علامتی ندارم", noSymptoms) {
                noSymptoms = true; symptoms = emptySet(); pain = -1
            }
            ChoiceChipPill("دارم / جزئیات", !noSymptoms && (symptoms.isNotEmpty() || pain >= 0 || showExtra)) {
                noSymptoms = false; showExtra = true
            }
        }
        if (!noSymptoms) {
            SectionLabel("علائم جسمی")
            val opts = listOf("pain" to "درد", "bloating" to "نفخ", "headache" to "سردرد", "breast_tenderness" to "حساسیت سینه", "nausea" to "تهوع", "acne" to "جوش")
            opts.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    row.forEach { (k, label) ->
                        ChoiceChipPill(label, k in symptoms, selectedColor = MahavaPrimary) {
                            symptoms = if (k in symptoms) symptoms - k else symptoms + k
                        }
                    }
                }
            }
            SectionLabel("سطح انرژی")
            FlowChoices(listOf("low" to "کم", "medium" to "متوسط", "high" to "زیاد"), energy) { energy = it }
            SectionLabel("شدت درد (۰ تا ۱۰) — اختیاری")
            Slider(
                value = if (pain < 0) 0f else pain.toFloat(),
                onValueChange = { pain = it.toInt() },
                valueRange = 0f..10f,
                steps = 9
            )
            Text(if (pain < 0) "انتخاب نشده" else PersianDigits.toPersian(pain))
            if (showExtra) {
                SectionLabel("ترشحات (اختیاری)")
                FlowChoices(
                    listOf("dry" to "خشک", "sticky" to "چسبناک", "creamy" to "کرمی", "watery" to "آبکی", "eggwhite" to "شفاف/کشسان"),
                    discharge
                ) { discharge = it }
            }
        }
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("یادداشت امروز (اختیاری)") }
        Spacer(Modifier.height(16.dp))
        PrimaryButton("ذخیره روی گوشی") {
            val now = System.currentTimeMillis()
            vm.saveDailyLog(
                DailyLogEntity(
                    epochDay = day.toEpochDay(),
                    bleeding = bleeding,
                    noSymptoms = noSymptoms,
                    painScore = pain.takeIf { it >= 0 },
                    physicalSymptoms = symptoms.joinToString(",").ifBlank { null },
                    moods = mood,
                    energy = energy,
                    discharge = discharge,
                    note = note.ifBlank { null },
                    createdAt = now,
                    updatedAt = now
                )
            )
            saved = true
            onBack()
        }
        if (saved) QuietInfo("ذخیره شد")
        QuietInfo("ذخیره مجدد همان روز رکورد تکراری نمی‌سازد.")
    }
}

@Composable
private fun FlowChoices(options: List<Pair<String, String>>, selected: String?, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, label) ->
            ChoiceChipPill(label, selected == k) { onSelect(k) }
        }
    }
}

@Composable
fun PeriodLogScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val last = state.periods.lastOrNull()
    var start by remember { mutableStateOf(last?.let { LocalDate.ofEpochDay(it.startEpochDay) } ?: vm.today()) }
    var end by remember { mutableStateOf(last?.endEpochDay?.let { LocalDate.ofEpochDay(it) }) }
    var ongoing by remember { mutableStateOf(last?.stillOngoing == true || last?.endEpochDay == null) }
    var flow by remember { mutableStateOf("medium") }
    var pain by remember { mutableIntStateOf(5) }
    var impact by remember { mutableStateOf("medium") }
    var clots by remember { mutableStateOf("none") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("ثبت پریود", onBack = onBack)
        SectionLabel("شروع خون‌ریزی")
        Text(JalaliDate.from(start).formatFa())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceChipPill("امروز", false) { start = vm.today(); if (start.isAfter(vm.today())) start = vm.today() }
            ChoiceChipPill("دیروز", false) { start = vm.today().minusDays(1) }
            ChoiceChipPill("۲ روز قبل", false) { start = vm.today().minusDays(2) }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("هنوز ادامه دارد", Modifier.weight(1f)); Switch(checked = ongoing, onCheckedChange = { ongoing = it; if (it) end = null })
        }
        if (!ongoing) {
            SectionLabel("پایان خون‌ریزی")
            Text(end?.let { JalaliDate.from(it).formatFa() } ?: "انتخاب نشده")
            ChoiceChipPill("امروز به‌عنوان پایان", false) { end = vm.today() }
        }
        SectionLabel("میزان خون‌ریزی")
        FlowChoices(listOf("light" to "کم", "medium" to "متوسط", "heavy" to "زیاد"), flow) { flow = it }
        SectionLabel("شدت درد")
        Slider(value = pain.toFloat(), onValueChange = { pain = it.toInt() }, valueRange = 0f..10f, steps = 9)
        Text(PersianDigits.toPersian(pain))
        SectionLabel("اثر بر فعالیت")
        FlowChoices(listOf("none" to "ندارد", "partial" to "جزئی", "medium" to "متوسط", "high" to "زیاد"), impact) { impact = it }
        SectionLabel("لخته")
        FlowChoices(listOf("none" to "ندارد", "sometimes" to "گاهی", "frequent" to "مکرر"), clots) { clots = it }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("ذخیره پریود") {
            vm.savePeriod(start, end, ongoing)
            // also mirror intensity into today's daily log without inventing symptoms if not wanted
            val now = System.currentTimeMillis()
            vm.saveDailyLog(
                DailyLogEntity(
                    epochDay = start.toEpochDay(),
                    bleeding = flow,
                    painScore = pain,
                    painActivityImpact = impact,
                    clots = clots,
                    createdAt = now,
                    updatedAt = now
                )
            )
            onBack()
        }
        QuietInfo("پیش‌بینی پایان، پایان واقعی ذخیره نمی‌شود. لکه‌بینی خودکار چرخه جدید نمی‌سازد.")
    }
}
