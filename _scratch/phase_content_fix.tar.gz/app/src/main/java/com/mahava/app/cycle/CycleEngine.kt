package com.mahava.app.cycle

import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Deterministic cycle engine (algorithmVersion = mahava-cycle-1.0.0).
 *
 * Fertility window basis (documented, not a clinical guarantee):
 * - NHS: ovulation typically ~10–16 days before the next period; sperm may survive up to ~7 days;
 *   egg lives ~12–24 hours (also cited by OWH/womenshealth.gov).
 * - OWH: most fertile in the 3 days before ovulation through ovulation day; sperm 3–5 days, egg 12–24h.
 * We therefore estimate ovulation as a range relative to the predicted next-period window,
 * anchor ovulation near (nextPeriodCentral - 14) ± 3 days (NHS 10–16), fertility [ovEarliest - 5, ovLatest + 1] (Wilcox-style ~6d window ending near ovulation).
 * We NEVER claim a fixed day-14 ovulation for all users, never emit pregnancy probability %,
 * and never materialize predictions as real period events.
 */
class CycleEngine {

    data class Input(
        val today: LocalDate,
        val periods: List<PeriodInterval>,
        val typicalCycleLength: Int?, // user-confirmed; null = unknown
        val typicalBleedLength: Int?,
        val regularCycles: Boolean?,
        val hormonalContraception: Boolean = false,
        val postpartumOrBreastfeeding: Boolean = false,
        val perimenopause: Boolean = false,
        val pregnancyMode: Boolean = false,
        val fertilityTrackingEnabled: Boolean = false,
        val maxCyclesForMedian: Int = 6
    )

    fun compute(input: Input): CycleEngineResult {
        val confirmed = input.periods
            .filter { it.confirmedByUser }
            .sortedBy { it.start }

        val lastStart = confirmed.lastOrNull()?.start
        val ongoing = confirmed.lastOrNull()?.let { it.isOngoing() && !it.start.isAfter(input.today) } == true

        val restriction = when {
            input.pregnancyMode -> PredictionRestriction.PREGNANCY_MODE
            input.hormonalContraception -> PredictionRestriction.HORMONAL_CONTRACEPTION
            input.postpartumOrBreastfeeding -> PredictionRestriction.POSTPARTUM_OR_BREASTFEEDING
            input.perimenopause -> PredictionRestriction.PERIMENOPAUSE
            input.regularCycles == false -> PredictionRestriction.IRREGULAR
            else -> PredictionRestriction.NONE
        }

        val cycleDay = lastStart?.let {
            val d = (input.today.toEpochDay() - it.toEpochDay() + 1).toInt()
            if (d < 1) null else d
        }

        val bleedingDay = if (ongoing && lastStart != null) {
            (input.today.toEpochDay() - lastStart.toEpochDay() + 1).toInt().takeIf { it >= 1 }
        } else null

        val samples = cycleSamples(confirmed)
        val predictionAllowed = restriction == PredictionRestriction.NONE ||
            restriction == PredictionRestriction.IRREGULAR // irregular -> unknown estimate below

        val pred: PredictionKind
        val effectiveRestriction: PredictionRestriction
        val basis: String
        val limits: String
        val reason: String

        when {
            input.pregnancyMode -> {
                pred = PredictionKind.Unknown
                effectiveRestriction = PredictionRestriction.PREGNANCY_MODE
                basis = "حالت بارداری توسط کاربر فعال شده است."
                limits = "پیش‌بینی چرخه معمول متوقف شده است."
                reason = "کاربر نتیجه تست مثبت یا حالت بارداری را انتخاب کرده است."
            }
            !predictionAllowed || restriction in setOf(
                PredictionRestriction.HORMONAL_CONTRACEPTION,
                PredictionRestriction.POSTPARTUM_OR_BREASTFEEDING,
                PredictionRestriction.PERIMENOPAUSE
            ) -> {
                pred = PredictionKind.Unknown
                effectiveRestriction = restriction
                basis = "شرایط ثبت‌شده برای پیش‌بینی تقویمی مناسب نیست."
                limits = "ثبت و آموزش ادامه دارد؛ تخمین باروری/پریود محدود شده است."
                reason = restriction.name
            }
            restriction == PredictionRestriction.IRREGULAR -> {
                pred = PredictionKind.Unknown
                effectiveRestriction = PredictionRestriction.IRREGULAR
                basis = "چرخه نامنظم گزارش شده است."
                limits = "بازه قطعی پریود یا باروری ارائه نمی‌شود."
                reason = "irregular"
            }
            samples.size >= 2 -> {
                val used = samples.takeLast(input.maxCyclesForMedian)
                val median = medianInt(used.map { it.lengthDays })
                val variability = max(2, (mad(used.map { it.lengthDays }) * 1.5).roundToInt().coerceAtLeast(2))
                // Extra uncertainty when few cycles
                val dataPad = when (used.size) {
                    2 -> 2
                    3 -> 1
                    else -> 0
                }
                val half = variability + dataPad
                val anchor = lastStart!!
                val central = anchor.plusDays(median.toLong())
                val earliest = central.minusDays(half.toLong())
                val latest = central.plusDays(half.toLong())
                // Luteal-anchored: ovulation ~10–16d before next period (NHS). Use central-14 ±3
                // so fertility band stays educationally narrow (Wilcox ~6d fertile ending on ovulation).
                val ovCentral = central.minusDays(14)
                val ovEarliest = ovCentral.minusDays(3)
                val ovLatest = ovCentral.plusDays(3)
                val fertEarliest = ovEarliest.minusDays(5)
                val fertLatest = ovLatest.plusDays(1)
                pred = PredictionKind.Estimate(
                    medianCycleLength = median,
                    cyclesUsed = used.size,
                    nextPeriodStartEarliest = earliest,
                    nextPeriodStartLatest = latest,
                    nextPeriodStartCentral = central,
                    ovulationEarliest = minDate(ovEarliest, ovLatest),
                    ovulationLatest = maxDate(ovEarliest, ovLatest),
                    fertilityEarliest = minDate(fertEarliest, fertLatest),
                    fertilityLatest = maxDate(fertEarliest, fertLatest)
                )
                effectiveRestriction = PredictionRestriction.NONE
                basis = "بر پایه میانه ${used.size} چرخهٔ ثبت‌شده (میانه $median روز) — نه درصد دقت."
                limits = "پیش‌بینی رویداد واقعی ایجاد نمی‌کند؛ درصد دقت یا احتمال بارداری ارائه نمی‌شود."
                reason = "median_recent_cycles"
            }
            input.typicalCycleLength != null && lastStart != null -> {
                val L = input.typicalCycleLength
                val half = 3 // minimum uncertainty for single user-stated length
                val central = lastStart.plusDays(L.toLong())
                val earliest = central.minusDays(half.toLong())
                val latest = central.plusDays(half.toLong())
                val ovCentral = central.minusDays(14)
                val ovEarliest = ovCentral.minusDays(3)
                val ovLatest = ovCentral.plusDays(3)
                val fertEarliest = ovEarliest.minusDays(5)
                val fertLatest = ovLatest.plusDays(1)
                pred = PredictionKind.Estimate(
                    medianCycleLength = L,
                    cyclesUsed = 0,
                    nextPeriodStartEarliest = earliest,
                    nextPeriodStartLatest = latest,
                    nextPeriodStartCentral = central,
                    ovulationEarliest = minDate(ovEarliest, ovLatest),
                    ovulationLatest = maxDate(ovEarliest, ovLatest),
                    fertilityEarliest = minDate(fertEarliest, fertLatest),
                    fertilityLatest = maxDate(fertEarliest, fertLatest)
                )
                effectiveRestriction = PredictionRestriction.NONE
                basis = "بر پایه طول چرخهٔ تأییدشدهٔ تو ($L روز) — نه درصد دقت."
                limits = "عدم قطعیت حداقل ±$half روز؛ پیش‌بینی قطعی نیست."
                reason = "user_stated_cycle_length"
            }
            else -> {
                pred = PredictionKind.Unknown
                effectiveRestriction = PredictionRestriction.INSUFFICIENT_DATA
                basis = "داده کافی برای تخمین نیست."
                limits = "ثبت و آموزش ممکن است؛ تخمین قطعی نمایش داده نمی‌شود."
                reason = "insufficient_data"
            }
        }

        val daysUntil: Int?
        val late: Boolean
        val daysLate: Int?
        when (val p = pred) {
            is PredictionKind.Estimate -> {
                val delta = (p.nextPeriodStartCentral.toEpochDay() - input.today.toEpochDay()).toInt()
                if (delta < 0) {
                    daysUntil = null
                    late = true
                    daysLate = -delta
                } else {
                    daysUntil = delta
                    late = false
                    daysLate = null
                }
            }
            else -> {
                daysUntil = null
                late = false
                daysLate = null
            }
        }

        val phase = inferPhase(
            cycleDay = cycleDay,
            today = input.today,
            ongoingPeriod = ongoing,
            typicalBleed = input.typicalBleedLength,
            lastPeriod = confirmed.lastOrNull(),
            prediction = pred
        )

        val showFertility = input.fertilityTrackingEnabled &&
            pred is PredictionKind.Estimate &&
            effectiveRestriction == PredictionRestriction.NONE

        return CycleEngineResult(
            algorithmVersion = CycleEngineResult.ALGORITHM_VERSION,
            today = input.today,
            cycleDay = cycleDay,
            phase = phase,
            lastPeriodStart = lastStart,
            bleedingDay = bleedingDay,
            periodOngoing = ongoing,
            daysUntilCentralPeriod = daysUntil,
            isLate = late,
            daysLate = daysLate,
            prediction = pred,
            restriction = effectiveRestriction,
            basisDescriptionFa = basis,
            limitsDescriptionFa = limits,
            reasonFa = reason,
            showFertility = showFertility
        )
    }

    fun cycleSamples(periods: List<PeriodInterval>): List<CycleLengthSample> {
        val starts = periods.map { it.start }.distinct().sorted()
        if (starts.size < 2) return emptyList()
        val out = mutableListOf<CycleLengthSample>()
        for (i in 0 until starts.lastIndex) {
            val a = starts[i]
            val b = starts[i + 1]
            val len = (b.toEpochDay() - a.toEpochDay()).toInt()
            if (len in 15..90) { // keep extreme but plausible; do not silently drop without reason in UI
                out += CycleLengthSample(a, b, len)
            }
        }
        return out
    }

    private fun inferPhase(
        cycleDay: Int?,
        today: LocalDate,
        ongoingPeriod: Boolean,
        typicalBleed: Int?,
        lastPeriod: PeriodInterval?,
        prediction: PredictionKind
    ): CyclePhase {
        if (cycleDay == null) return CyclePhase.UNKNOWN
        if (ongoingPeriod) return CyclePhase.MENSTRUATION
        if (lastPeriod?.endInclusive != null) {
            val end = lastPeriod.endInclusive
            if (!today.isAfter(end) && !today.isBefore(lastPeriod.start)) return CyclePhase.MENSTRUATION
        } else if (typicalBleed != null && cycleDay <= typicalBleed) {
            // only soft hint when period ended unknown — still prefer UNKNOWN for bleed if not ongoing
        }
        when (prediction) {
            is PredictionKind.Estimate -> {
                if (!today.isBefore(prediction.ovulationEarliest) && !today.isAfter(prediction.ovulationLatest)) {
                    return CyclePhase.OVULATION_WINDOW
                }
                val central = prediction.nextPeriodStartCentral
                val lutealStartApprox = prediction.ovulationLatest.plusDays(1)
                if (!today.isBefore(lutealStartApprox) && today.isBefore(central)) return CyclePhase.LUTEAL
                if (cycleDay >= 1 && today.isBefore(prediction.ovulationEarliest)) {
                    // after bleed
                    return if (ongoingPeriod) CyclePhase.MENSTRUATION else CyclePhase.FOLLICULAR
                }
            }
            else -> Unit
        }
        return CyclePhase.UNKNOWN
    }

    private fun medianInt(values: List<Int>): Int {
        require(values.isNotEmpty())
        val s = values.sorted()
        val m = s.size / 2
        return if (s.size % 2 == 1) s[m] else ((s[m - 1] + s[m]) / 2.0).roundToInt()
    }

    private fun mad(values: List<Int>): Double {
        if (values.isEmpty()) return 0.0
        val med = medianInt(values).toDouble()
        val deviations = values.map { kotlin.math.abs(it - med) }.sorted()
        val m = deviations.size / 2
        return if (deviations.size % 2 == 1) deviations[m] else (deviations[m - 1] + deviations[m]) / 2.0
    }

    private fun minDate(a: LocalDate, b: LocalDate) = if (a.isBefore(b)) a else b
    private fun maxDate(a: LocalDate, b: LocalDate) = if (a.isAfter(b)) a else b
}
