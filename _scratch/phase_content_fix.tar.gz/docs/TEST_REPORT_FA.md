# گزارش تست ماه‌آوا (دستگاه واقعی)

تاریخ: ۱۴۰۵/۰۷/۱۴ ≈ 2026-10-06 (Asia/Tehran, UTC+3:30)

دستگاه: Redmi Note 12 Pro (2209116AG) — serial `32c08acb0013` — Android 13 — ۱۰۸۰×۲۴۰۰  
ADB: `C:\Users\A.R.I\AppData\Local\Android\Sdk\platform-tools\adb.exe`  
APK: فقط `com.mahava.app` با `adb install -r Mahava-debug.apk` (تأیید صریح کاربر). هیچ اپ/دادهٔ دیگری دست نخورده است.

## ساخت و نصب
- `assembleDebug`: موفق (چند دور پس از اصلاح RTL / seed / onNewIntent)
- نصب: Success
- unit tests قبلی: ۲۵/۲۵ سبز (بدون رگرسیون در این دور دستگاهی جداگانه دوباره اجرا نشد)

## محدودیت‌های Xiaomi (بدون «USB debugging (Security settings)»)
| عمل | نتیجه |
|-----|--------|
| `adb shell input` / `uiautomator` | SecurityException: INJECT_EVENTS |
| `pm clear com.mahava.app` | SecurityException: CLEAR_APP_USER_DATA |
| `settings put system font_scale` | SecurityException: WRITE_SETTINGS |
| نصب androidTest APK | INSTALL_FAILED_USER_RESTRICTED (قبلاً) |

کار جایگزین انجام‌شده: deep linkهای `mahava://qa/seed` و `mahava://screen/*` + `screencap` (با `svc power stayon true` چون صفحه خاموش می‌شد و keyevent هم بلاک بود).

**پاک‌سازی داده در پایان انجام نشد** — کاربر باید دستی در تنظیمات اندروید → برنامه‌ها → ماه‌آوا → پاک کردن داده، یا Security USB debugging را روشن کند تا `pm clear` کار کند. دادهٔ seed حداقلی روی دستگاه مانده است.

**آزمون فونت بزرگ (۱٫۳) انجام نشد** — همان بلوک WRITE_SETTINGS؛ `font_scale` روی ۱٫۰ ماند.

## مسیر UI روی دستگاه (deep link)
پیمایش شد (نه با input، بلکه با force-stop + VIEW intent):

1. onboarding خوش‌آمد  
2. امروز  
3. تقویم  
4. هاب ثبت / ثبت حال امروز / ثبت پریود  
5. گزارش‌ها / گزارش پزشک / تأخیر و تست  
6. شناخت بدن (خانه + هر ۶ دسته)  
7. مراقبت  
8. تنظیمات (قفل، پشتیبان/بازیابی به‌صورت بخش‌های داخل همان صفحه — صفحهٔ جداگانه backup/restore/delete نداریم؛ تأیید حذف با deep link جدا نیست و بدون inject باز نشد)

ذخیرهٔ واقعی روزانه با لمس دکمه به‌خاطر بلوک input تأیید نشد؛ UI فرم و دکمهٔ ذخیره دیده شد.

## کرش (logcat)
- فیلتر FATAL / AndroidRuntime برای پکیج در بازهٔ walk: **هیچ FATAL EXCEPTION مرتبط با ماه‌آوا دیده نشد**.
- برخی خطوط VerityUtils/SQLiteLog سیستمی هنگام نصب بی‌ربط به UI بودند.

## اصلاحات این دور (کد)
1. **اجبار RTL**: `CompositionLocalProvider(LocalLayoutDirection.Rtl)` در Theme + locale `fa` در Application  
2. تاریخ‌ها/اعداد فارسی در امروز و سرچستون‌های تقویم  
3. **seed QA**: ذخیرهٔ بازهٔ خون‌ریزی واقعی داخل ماه جاری تا علامت «واقعی» روی تقویم دیده شود  
4. **MainActivity**: `onNewIntent` برای deep link بدون kill؛ `FLAG_KEEP_SCREEN_ON` / turnScreenOn برای QA  
5. بازسازی و نصب مجدد APK

## مقایسه با board مرجع (چشمی با Read، نه پیکسلی)
| صفحه | وضعیت در برابر board |
|------|----------------------|
| خوش‌آمد onboarding | نزدیک؛ RTL و هدف‌ها درست |
| امروز | حلقه، کارت‌ها، ناوبری راست→چپ درست (امروز راست‌ترین). کارت آموزشی «در بدنم چه می‌گذرد؟» و جای تصویر نسبت به mockup کامل نیست |
| تقویم | ش…ج از راست؛ اعداد فارسی؛ **دایرهٔ توپر صورتی واقعی** پس از seed دیده شد. بازهٔ باروری تخمینی با seed دوتایی گاهی خیلی پهن دیده شد |
| ثبت حال | فرم کامل با چیپ؛ mockup صورتک/آیکون انرژی را ندارد (چیپ متنی) |
| شناخت بدن | ۶ دسته + جزئیات؛ تصویر مرحلهٔ امروز |
| تأخیر/تست و مراقبت | محتوا و تصویر هست؛ وفادار به نقش آموزشی |
| تنظیمات | حریم خصوصی، هدف، تقویم، قفل، یادآوری، پشتیبان رمزدار — حذف با تأیید در همان اسکرول |

## اسکرین‌شات‌ها
PC: `C:\Users\A.R.I\Desktop\app\mahava\screenshots\`  
Box: `/workspace/mahava/out/screenshots/`

فایل‌های اصلی معتبر:  
`01_onboarding_welcome`, `05_today`, `06_calendar`, `07_log_hub`, `08_daily_log`, `09_period_log`, `10_reports`, `11_late_test`, `12_doctor_report`, `13_body_home`, `14`–`19` دسته‌های بدن, `21_settings`, `24_care`

**بهترین‌ها برای نمایش به کاربر (۶ تا):**  
1. `01_onboarding_welcome.png`  
2. `05_today.png`  
3. `06_calendar.png`  
4. `08_daily_log.png`  
5. `13_body_home.png`  
6. `11_late_test.png` (یا `24_care.png` / `21_settings.png`)

توجه: فایل‌های ~۱۵۵۸۰ بایت از وقتی صفحه خاموش بود سیاه/خالی‌اند؛ با stayon دوباره گرفته شدند.

## باقی‌مانده / تأییدنشده
- لمس واقعی دکمه‌ها، ذخیرهٔ لاگ، شروع/پایان پریود با gesture  
- تأیید حذف داده و قفل بیومتریک end-to-end روی UI  
- font_scale ۱٫۳ و restore  
- `pm clear` در پایان  
- تطابق پیکسلی با board  
- کارت آموزشی پایین صفحهٔ امروز و آیکون‌های صورتک لاگ روزانه  
- جدا کردن صفحات backup/restore/delete به‌جای بخش‌های settings  
- دقت بازهٔ باروری وقتی چند period seed می‌شود

## جمع‌بندی
نصب و walk اصلی بدون کرش؛ RTL و ناوبری و تقویم با علامت واقعی پس از اصلاح seed قابل قبول‌اند. محدودیت امنیتی شیائومی مانع input، فونت بزرگ، و پاک‌سازی خودکار شد — کاربر باید دادهٔ seed را دستی پاک کند یا Security USB debugging را فعال کند.
