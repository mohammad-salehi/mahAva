package com.mahava.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahava.app.cycle.PredictionKind
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import com.mahava.app.util.JalaliDate
import com.mahava.app.util.PersianDigits
import java.time.LocalDate

@Composable
fun CalendarScreen(vm: AppViewModel, onSettings: () -> Unit, onOpenDay: (LocalDate) -> Unit) {
    val state by vm.state.collectAsState()
    val useJalali = state.profile?.calendarType != "gregorian"
    var monthAnchor by remember { mutableStateOf(vm.today().withDayOfMonth(1)) }
    val today = vm.today()
    val periodDays = remember(state.periods) {
        buildSet {
            state.periods.forEach { p ->
                val start = p.startEpochDay
                val end = p.endEpochDay ?: today.toEpochDay()
                for (d in start..end) add(d)
            }
        }
    }
    val predictedPeriod = mutableSetOf<Long>()
    val predictedFertile = mutableSetOf<Long>()
    val pred = state.cycle?.prediction
    if (pred is PredictionKind.Estimate) {
        var d = pred.nextPeriodStartEarliest
        while (!d.isAfter(pred.nextPeriodStartLatest)) {
            if (d.isAfter(today)) predictedPeriod += d.toEpochDay()
            d = d.plusDays(1)
        }
        if (state.cycle?.showFertility == true) {
            var f = pred.fertilityEarliest
            while (!f.isAfter(pred.fertilityLatest)) {
                if (f.isAfter(today) || f == today) predictedFertile += f.toEpochDay()
                f = f.plusDays(1)
            }
        }
    }

    val days = monthDays(monthAnchor)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("تقویم", onSettings = onSettings)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            androidx.compose.material3.IconButton(onClick = { monthAnchor = monthAnchor.minusMonths(1) }) { MahavaIcon(com.mahava.app.R.drawable.ic_chevron_right) }
            Text(
                if (useJalali) {
                    val j = JalaliDate.from(monthAnchor.plusDays(15))
                    "${JalaliDate.monthNameFa(j.month)} ${PersianDigits.toPersian(j.year)}"
                } else monthAnchor.month.name + " " + monthAnchor.year,
                style = MaterialTheme.typography.titleLarge
            )
            androidx.compose.material3.IconButton(onClick = { monthAnchor = monthAnchor.plusMonths(1) }) { MahavaIcon(com.mahava.app.R.drawable.ic_chevron_left) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            // RTL: first cell is on the right => Saturday-first Iranian week
            listOf("ش","ی","د","س","چ","پ","ج").forEach {
                Text(it, modifier = Modifier.width(40.dp), color = MahavaTextSecondary, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                week.forEach { day ->
                    if (day == null) Box(Modifier.size(40.dp))
                    else {
                        val epoch = day.toEpochDay()
                        val actual = epoch in periodDays
                        val predP = epoch in predictedPeriod && !actual
                        val fert = epoch in predictedFertile && !actual
                        val isToday = day == today
                        DayCell(day, useJalali, actual, predP, fert, isToday) {
                            onOpenDay(day)
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Legend()
            MahavaCard {
                Text("روز ${state.cycle?.cycleDay?.let { PersianDigits.toPersian(it) } ?: "؟"} چرخه", style = MaterialTheme.typography.titleMedium)
                QuietInfo("لمس هر روز برای مشاهده/ویرایش. روزهای آینده فقط پیش‌بینی دارند. پیش‌بینی رویداد واقعی نمی‌سازد.")
                val note = vm.logFor(today)?.note
                Text("یادداشت امروز: ${note?.takeIf { it.isNotBlank() } ?: "ثبت نشده"}")
            }
            SecondaryButton("برو به امروز") { monthAnchor = today.withDayOfMonth(1) }
        }
    }
}

@Composable private fun DayCell(
    day: LocalDate, jalali: Boolean, actual: Boolean, pred: Boolean, fert: Boolean, isToday: Boolean, onClick: () -> Unit
) {
    val label = if (jalali) PersianDigits.toPersian(JalaliDate.from(day).day) else PersianDigits.toPersian(day.dayOfMonth)
    Box(Modifier.size(40.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        when {
            actual -> Box(Modifier.size(34.dp).background(MahavaMenstruation, CircleShape), contentAlignment = Alignment.Center) {
                Text(label, color = Color.White, fontSize = 13.sp)
            }
            pred -> DashedCircle(MahavaMenstruation) { Text(label, fontSize = 13.sp, color = MahavaTextPrimary) }
            fert -> DashedCircle(MahavaFertility) { Text(label, fontSize = 13.sp, color = MahavaTextPrimary) }
            isToday -> Box(Modifier.size(34.dp).background(MahavaFertility, CircleShape), contentAlignment = Alignment.Center) {
                Text(label, color = Color.White, fontSize = 13.sp)
            }
            else -> Text(label, fontSize = 13.sp, color = MahavaTextPrimary)
        }
    }
}

@Composable private fun DashedCircle(color: Color, content: @Composable () -> Unit) {
    Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                color = color,
                style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
            )
        }
        content()
    }
}

@Composable private fun Legend() {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("● واقعی", color = MahavaMenstruation, fontSize = 12.sp)
        Text("◌ پیش‌بینی", color = MahavaMenstruation, fontSize = 12.sp)
        Text("◌ باروری تخمینی", color = MahavaFertility, fontSize = 12.sp)
    }
}

private fun monthDays(anchor: LocalDate): List<LocalDate?> {
    val first = anchor.withDayOfMonth(1)
    // Saturday=6 in ISO; we want Saturday-first for Iran
    val shift = (first.dayOfWeek.value % 7) // Mon=1..Sun=7 -> Sat=6 -> 6, Sun=0
    val startPad = (first.dayOfWeek.value % 7) // if Sat(6): 6, Sun(7):0, Mon(1):1 ...
    // For Sat-first grid: number of blanks before day 1
    val blank = when (first.dayOfWeek.value) {
        6 -> 0; 7 -> 1; 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 5; 5 -> 6; else -> 0
    }
    val daysInMonth = anchor.lengthOfMonth()
    val list = MutableList<LocalDate?>(blank) { null }
    for (d in 1..daysInMonth) list += anchor.withDayOfMonth(d)
    while (list.size % 7 != 0) list += null
    return list
}
