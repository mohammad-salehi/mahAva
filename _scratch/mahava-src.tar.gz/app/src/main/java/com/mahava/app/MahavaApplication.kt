package com.mahava.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.mahava.app.content.ContentRepository
import com.mahava.app.data.backup.BackupManager
import com.mahava.app.data.crypto.CryptoManager
import com.mahava.app.data.db.MahavaDatabase
import com.mahava.app.data.prefs.UserPreferences
import com.mahava.app.data.repo.MahavaRepository
import com.mahava.app.reminders.ReminderScheduler
import com.mahava.app.util.AppClock
import com.mahava.app.util.SystemAppClock

class MahavaApplication : Application() {
    lateinit var clock: AppClock
        private set
    lateinit var database: MahavaDatabase
        private set
    lateinit var repository: MahavaRepository
        private set
    lateinit var contentRepository: ContentRepository
        private set
    lateinit var backupManager: BackupManager
        private set
    lateinit var prefs: UserPreferences
        private set
    lateinit var reminderScheduler: ReminderScheduler
        private set
    lateinit var cryptoManager: CryptoManager
        private set

    override fun onCreate() {
        super.onCreate()
        clock = SystemAppClock()
        database = MahavaDatabase.build(this)
        repository = MahavaRepository(database, clock)
        contentRepository = ContentRepository(this)
        cryptoManager = CryptoManager()
        backupManager = BackupManager(database, cryptoManager)
        prefs = UserPreferences(this)
        reminderScheduler = ReminderScheduler(this)
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                ReminderScheduler.CHANNEL_ID,
                getString(R.string.notification_channel_reminders),
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(ch)
        }
    }
}
