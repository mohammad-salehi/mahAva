package com.mahava.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mahava.app.R
import com.mahava.app.content.BodyCategories
import com.mahava.app.cycle.CyclePhase
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*

@Composable
fun BodyHomeScreen(vm: AppViewModel, onSettings: () -> Unit, onCategory: (String) -> Unit, onCare: () -> Unit) {
    val state by vm.state.collectAsState()
    val phase = state.cycle?.phase
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("بدن من امروز", onSettings = onSettings)
        MahavaCard(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحله احتمالی امروز", color = MahavaTextSecondary)
                    Text(
                        when (phase) {
                            CyclePhase.MENSTRUATION -> "خون‌ریزی"
                            CyclePhase.FOLLICULAR -> "فولیکولی"
                            CyclePhase.OVULATION_WINDOW -> "بازه تخمک‌گذاری تخمینی"
                            CyclePhase.LUTEAL -> "لوتئال"
                            else -> "نامشخص"
                        },
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                Illustration(R.drawable.ill_daily_woman, Modifier.width(100.dp).height(72.dp))
            }
        }
        val cats = listOf(
            BodyCategories.PERIOD_PAIN to (R.drawable.ic_droplet to "پریود و درد"),
            BodyCategories.CYCLE_HORMONES to (R.drawable.ic_uterus to "چرخه و هورمون‌ها"),
            BodyCategories.SLEEP_MOOD to (R.drawable.ic_moon to "خواب و حال روحی"),
            BodyCategories.FERTILITY_DISCHARGE to (R.drawable.ic_leaf to "باروری و ترشحات"),
            BodyCategories.DIGESTION_SKIN to (R.drawable.ic_heart to "گوارش و پوست"),
            BodyCategories.PATTERN_CARE to (R.drawable.ic_book to "الگو و مراقبت")
        )
        val hidden = state.profile?.hiddenBodyCategories?.split(',')?.toSet() ?: emptySet()
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            cats.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (id, pair) ->
                        if (id !in hidden) {
                            MahavaCard(Modifier.weight(1f).clickable { onCategory(id) }) {
                                MahavaIcon(pair.first)
                                Spacer(Modifier.height(8.dp))
                                Text(pair.second, style = MaterialTheme.typography.titleMedium)
                            }
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            MahavaCard(Modifier.clickable(onClick = onCare)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MahavaIcon(R.drawable.ic_note)
                    Spacer(Modifier.width(8.dp))
                    Text("با ثبت علائم، الگوی بدنت روشن‌تر می‌شود.")
                }
            }
        }
    }
}

@Composable
fun BodyCategoryScreen(vm: AppViewModel, category: String, onBack: () -> Unit, onItem: (String) -> Unit) {
    val title = BodyCategories.all.find { it.first == category }?.second ?: category
    val items = vm.bodyItems(category)
    val ill = when (category) {
        BodyCategories.CYCLE_HORMONES -> R.drawable.ill_uterus_education
        BodyCategories.SLEEP_MOOD -> R.drawable.ill_rest_woman
        BodyCategories.FERTILITY_DISCHARGE -> R.drawable.ill_daily_woman
        BodyCategories.PATTERN_CARE -> R.drawable.ill_care_woman
        else -> R.drawable.ill_daily_woman
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(title, onBack = onBack)
        Illustration(ill, Modifier.padding(16.dp).height(140.dp))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (items.isEmpty()) QuietInfo("مطلب قابل نمایش برای شرایط فعلی نیست یا دسته پنهان شده است.")
            items.forEach { item ->
                MahavaCard(Modifier.clickable { onItem(item.id) }) {
                    Text(item.titleFa, style = MaterialTheme.typography.titleMedium)
                    QuietInfo(item.summaryFa)
                }
            }
            QuietInfo("وضعیت بازبینی: ${vm.contentStatus()}")
        }
    }
}

@Composable
fun BodyItemScreen(vm: AppViewModel, id: String, onBack: () -> Unit) {
    val item = vm.contentItem(id)
    val state by vm.state.collectAsState()
    val log = vm.logFor(vm.today())
    val ctx = vm.dayContext()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader(item?.titleFa ?: "مطلب", onBack = onBack)
        if (item == null) {
            Text("مطلب پیدا نشد")
            return
        }
        SectionLabel("امروز")
        QuietInfo("زیربازه تخمینی: ${ctx.subWindow.titleFa}" + (ctx.cycleDay?.let { " · روز ${com.mahava.app.util.PersianDigits.toPersian(it)} چرخه" } ?: ""))
        QuietInfo("آموزشی است — وضعیت قطعی بدن تو را اعلام نمی‌کند.")
        if (log != null) {
            QuietInfo(
                buildString {
                    append("ثبت امروز: ")
                    append(log.bleeding?.let { "خون‌ریزی=$it" } ?: "خون‌ریزی ثبت‌نشده")
                    log.painScore?.let { append(" · درد=${com.mahava.app.util.PersianDigits.toPersian(it)}") }
                    log.moods?.takeIf { it.isNotBlank() }?.let { append(" · خلق=$it") }
                    if (log.noSymptoms) append(" · هیچ علامتی ندارم")
                }
            )
        } else QuietInfo("برای امروز هنوز حالی ثبت نشده.")
        SectionLabel("در سابقه تو")
        val realPatterns = state.patterns
        if (realPatterns.isEmpty()) QuietInfo("هنوز الگوی کافی از ثبت‌های واقعی نداری — چیزی ساخته نمی‌شود.")
        else realPatterns.take(3).forEach { QuietInfo(it.textFa) }
        SectionLabel("توضیح علمی")
        Text(item.bodyFa, style = MaterialTheme.typography.bodyLarge)
        SectionLabel("چه کاری می‌توانی انجام بدهی؟")
        QuietInfo(item.whatYouCanDoFa ?: "ثبت منظم علائم و مراقبت عمومی متناسب.")
        SectionLabel("چه زمانی بررسی لازم است؟")
        QuietInfo(item.whenToSeekFa ?: "درد مقاوم، خون‌ریزی خیلی سنگین، یا علائم هشدار.")
        SectionLabel("منبع")
        item.sources.forEach {
            Text("• ${it.title} — ${it.org}")
            QuietInfo(it.url)
        }
        QuietInfo("تاریخ بررسی منبع در توسعه: ${item.sourceCheckedDate}")
        QuietInfo(item.medicalReviewStatus)
        QuietInfo("نسخه محتوا: ${item.contentVersion}")
    }
}
