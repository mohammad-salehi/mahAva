package com.mahava.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mahava.app.R
import com.mahava.app.cycle.CyclePhase
import com.mahava.app.cycle.PredictionKind
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import com.mahava.app.util.JalaliDate
import com.mahava.app.util.PersianDigits

@Composable
fun TodayScreen(vm: AppViewModel, onSettings: () -> Unit, onDailyLog: () -> Unit, onPeriod: () -> Unit, onBody: () -> Unit, onLate: () -> Unit) {
    val state by vm.state.collectAsState()
    val cycle = state.cycle
    val today = vm.today()
    val j = JalaliDate.from(today)
    val log = vm.logFor(today)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("امروز", style = MaterialTheme.typography.headlineLarge)
                Text(j.formatShortFa(), color = MahavaTextSecondary)
            }
            Illustration(R.drawable.ill_daily_woman, Modifier.width(110.dp).height(80.dp))
            IconButtonSettings(onSettings)
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            CycleRing(
                cycleDay = cycle?.cycleDay,
                cycleLengthHint = (cycle?.prediction as? PredictionKind.Estimate)?.medianCycleLength
                    ?: state.profile?.typicalCycleLength ?: 28,
                subtitle = phaseLabel(cycle?.phase)
            )
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (cycle?.isLate == true) {
                MahavaCard {
                    Text("تأخیر احتمالی", style = MaterialTheme.typography.titleLarge, color = MahavaMenstruation)
                    Text("حدود ${PersianDigits.toPersian(cycle.daysLate ?: 0)} روز از موعد تخمینی گذشته. شمارش منفی نمایش داده نمی‌شود.")
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton("تأخیر و تست") { onLate() }
                }
            } else {
                val pred = cycle?.prediction
                if (pred is PredictionKind.Estimate) {
                    MahavaCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MahavaIcon(R.drawable.ic_calendar, MahavaMenstruation)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    if (cycle.daysUntilCentralPeriod != null)
                                        "حدود ${PersianDigits.toPersian(cycle.daysUntilCentralPeriod)} روز تا پریود تخمینی"
                                    else "بازه پریود تخمینی",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    "${JalaliDate.from(pred.nextPeriodStartEarliest).formatShortFa()} تا ${JalaliDate.from(pred.nextPeriodStartLatest).formatShortFa()}",
                                    color = MahavaTextSecondary
                                )
                                QuietInfo("بر پایه ${PersianDigits.toPersian(pred.cyclesUsed)} چرخه / یا طول تأییدشده — نه درصد دقت.")
                            }
                        }
                    }
                    if (cycle.showFertility) {
                        MahavaCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                MahavaIcon(R.drawable.ic_leaf, MahavaFertility)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("بازه تخمینی باروری", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${JalaliDate.from(pred.fertilityEarliest).formatShortFa()} تا ${JalaliDate.from(pred.fertilityLatest).formatShortFa()}",
                                        color = MahavaTextSecondary
                                    )
                                    QuietInfo("تقویم روش جلوگیری نیست.")
                                }
                            }
                        }
                    }
                } else {
                    MahavaCard { Text("تخمین مرحله/پریود در حال حاضر نامشخص است."); QuietInfo(cycle?.basisDescriptionFa ?: "") }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickStat("درد", log?.painScore?.let { PersianDigits.toPersian(it) } ?: "ثبت نشده", Modifier.weight(1f))
                QuickStat("خلق‌وخو", log?.moods?.takeIf { it.isNotBlank() } ?: "ثبت نشده", Modifier.weight(1f))
                QuickStat("انرژی", energyFa(log?.energy), Modifier.weight(1f))
            }
            if (log == null) QuietInfo("نبود داده یعنی «ثبت نشده»، نه «بدون علامت».")
            else if (log.noSymptoms) QuietInfo("امروز «هیچ علامتی ندارم» را ثبت کرده‌ای.")

            PrimaryButton("ثبت حال امروز", onClick = onDailyLog)
            if (cycle?.periodOngoing == true) SecondaryButton("پایان/ویرایش پریود", onClick = onPeriod)
            else SecondaryButton("شروع/ثبت پریود", onClick = onPeriod)

            MahavaCard(Modifier) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Illustration(R.drawable.ill_daily_woman, Modifier.width(72.dp).height(56.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f).clickable(onClick = onBody)) {
                        Text("در بدنم چه می‌گذرد؟", style = MaterialTheme.typography.titleMedium)
                        QuietInfo("توضیح کوتاه علمی بر اساس منابع bundled")
                    }
                }
            }
            if (state.patterns.isNotEmpty()) {
                MahavaCard {
                    Text("الگوی شخصی", style = MaterialTheme.typography.titleLarge)
                    state.patterns.take(2).forEach { Text("• ${it.textFa}") }
                }
            }
            MahavaCard {
                Text("مراقبت مرتبط", style = MaterialTheme.typography.titleMedium)
                QuietInfo("برای درد خفیف: گرمای ملایم و حرکت سبک. در علائم جدی، کمک فوری محلی را در نظر بگیر.")
            }
            QuietInfo(cycle?.limitsDescriptionFa ?: "")
            QuietInfo("نسخه الگوریتم: ${cycle?.algorithmVersion ?: "-"}")
        }
    }
}

@Composable private fun QuickStat(title: String, value: String, modifier: Modifier) {
    MahavaCard(modifier) {
        Text(title, color = MahavaTextSecondary)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable private fun IconButtonSettings(onSettings: () -> Unit) {
    androidx.compose.material3.IconButton(onClick = onSettings, modifier = Modifier.size(48.dp)) {
        MahavaIcon(R.drawable.ic_settings, MahavaTextPrimary)
    }
}

private fun phaseLabel(phase: CyclePhase?): String = when (phase) {
    CyclePhase.MENSTRUATION -> "مرحله خون‌ریزی"
    CyclePhase.FOLLICULAR -> "فاز فولیکولی تخمینی"
    CyclePhase.OVULATION_WINDOW -> "نزدیک بازه تخمینی تخمک‌گذاری"
    CyclePhase.LUTEAL -> "فاز لوتئال تخمینی"
    else -> "مرحله نامشخص"
}

private fun energyFa(v: String?) = when (v) {
    "low" -> "کم"; "medium" -> "متوسط"; "high" -> "زیاد"; else -> "ثبت نشده"
}
