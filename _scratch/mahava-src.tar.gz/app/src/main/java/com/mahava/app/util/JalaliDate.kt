package com.mahava.app.util

import java.time.LocalDate

data class JalaliDate(val year: Int, val month: Int, val day: Int) : Comparable<JalaliDate> {
    init {
        require(month in 1..12) { "month out of range: $month" }
        require(day in 1..daysInMonth(year, month)) { "day out of range: $day for $year/$month" }
    }

    override fun compareTo(other: JalaliDate): Int =
        compareValuesBy(this, other, { it.year }, { it.month }, { it.day })

    fun toLocalDate(): LocalDate = JalaliConverter.toGregorian(this)

    fun plusDays(days: Long): JalaliDate = JalaliConverter.fromGregorian(toLocalDate().plusDays(days))

    fun formatFa(withYear: Boolean = true): String {
        val d = PersianDigits.toPersian(day)
        val mName = monthNameFa(month)
        return if (withYear) "$d $mName ${PersianDigits.toPersian(year)}" else "$d $mName"
    }

    fun formatShortFa(): String = "${PersianDigits.toPersian(day)} ${monthNameFa(month)}"

    companion object {
        fun from(localDate: LocalDate): JalaliDate = JalaliConverter.fromGregorian(localDate)

        fun monthNameFa(month: Int): String = when (month) {
            1 -> "فروردین"; 2 -> "اردیبهشت"; 3 -> "خرداد"
            4 -> "تیر"; 5 -> "مرداد"; 6 -> "شهریور"
            7 -> "مهر"; 8 -> "آبان"; 9 -> "آذر"
            10 -> "دی"; 11 -> "بهمن"; 12 -> "اسفند"
            else -> "?"
        }

        fun weekdayNameFa(localDate: LocalDate): String = when (localDate.dayOfWeek.value) {
            6 -> "شنبه"; 7 -> "یکشنبه"; 1 -> "دوشنبه"; 2 -> "سه‌شنبه"
            3 -> "چهارشنبه"; 4 -> "پنجشنبه"; 5 -> "جمعه"
            else -> ""
        }

        fun isLeap(year: Int): Boolean = JalaliConverter.isLeapJalali(year)

        fun daysInMonth(year: Int, month: Int): Int = when (month) {
            in 1..6 -> 31
            in 7..11 -> 30
            12 -> if (isLeap(year)) 30 else 29
            else -> error("bad month")
        }
    }
}

/**
 * Civil Jalali conversion (same family as widely used open algorithms).
 * Round-trip tested in unit tests; includes leap years.
 */
object JalaliConverter {
    fun isLeapJalali(jy: Int): Boolean {
        val r = jalCal(jy)
        return r.leap == 0
    }

    fun fromGregorian(g: LocalDate): JalaliDate {
        val gy = g.year
        val gm = g.monthValue
        val gd = g.dayOfMonth
        val jy = if (gy > 1600) 979 else 0
        val gy2 = if (gy > 1600) gy - 1600 else gy - 621
        val days = (365 * gy2 + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400)
            - 80 + gd + gMonthDays(gm, gy)) 
        // Use alternative stable method via epoch day offset from known anchor:
        return fromEpochDay(g.toEpochDay())
    }

    fun toGregorian(j: JalaliDate): LocalDate {
        return LocalDate.ofEpochDay(toEpochDay(j))
    }

    // Anchor: Gregorian 2026-03-21 = Jalali 1405-01-01 (Nowruz 1405)
    private const val ANCHOR_G_EPOCH = 20520L // LocalDate.of(2026,3,21).toEpochDay() computed at test time; we calculate dynamically
    private val ANCHOR_G: Long = LocalDate.of(2026, 3, 21).toEpochDay()
    private const val ANCHOR_J_YEAR = 1405
    private const val ANCHOR_J_MONTH = 1
    private const val ANCHOR_J_DAY = 1

    fun toEpochDay(j: JalaliDate): Long {
        var days = 0L
        // days from 1405-01-01 to j
        if (j.year == ANCHOR_J_YEAR) {
            days = dayOfYear(j) - 1L
        } else if (j.year > ANCHOR_J_YEAR) {
            for (y in ANCHOR_J_YEAR until j.year) days += if (isLeapJalali(y)) 366 else 365
            days += dayOfYear(j) - 1L
        } else {
            for (y in j.year until ANCHOR_J_YEAR) days -= if (isLeapJalali(y)) 366 else 365
            days += dayOfYear(j) - 1L
        }
        return ANCHOR_G + days
    }

    fun fromEpochDay(epochDay: Long): JalaliDate {
        var remaining = epochDay - ANCHOR_G
        var y = ANCHOR_J_YEAR
        if (remaining >= 0) {
            while (true) {
                val len = if (isLeapJalali(y)) 366 else 365
                if (remaining < len) break
                remaining -= len
                y++
            }
        } else {
            while (remaining < 0) {
                y--
                val len = if (isLeapJalali(y)) 366 else 365
                remaining += len
            }
        }
        val doy = remaining.toInt() + 1
        return fromDayOfYear(y, doy)
    }

    private fun dayOfYear(j: JalaliDate): Int {
        var d = j.day
        for (m in 1 until j.month) d += JalaliDate.daysInMonth(j.year, m)
        return d
    }

    private fun fromDayOfYear(year: Int, doy: Int): JalaliDate {
        var rem = doy
        for (m in 1..12) {
            val dim = JalaliDate.daysInMonth(year, m)
            if (rem <= dim) return JalaliDate(year, m, rem)
            rem -= dim
        }
        error("bad doy $doy")
    }

    private fun gMonthDays(gm: Int, gy: Int): Int {
        val leap = (gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)
        val md = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var s = 0
        for (i in 1 until gm) s += md[i]
        return s
    }

    // 33-year cycle leap calculation used by Iranian calendar libraries
    private data class JalCalResult(val leap: Int, val gy: Int, val march: Int)

    private fun jalCal(jy: Int): JalCalResult {
        val breaks = intArrayOf(
            -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
            1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
        )
        val bl = breaks.size
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until bl) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + (jump % 33) / 4
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + ((n % 33) + 3) / 4
        if ((jump % 33) == 4 && (jump - n) == 4) leapJ++
        val leapG = gy / 4 - ((gy / 100 + 1) * 3) / 4 - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = ((n + 1) % 33) - 1
        if (leap == -1) leap = 32
        return JalCalResult(leap, gy, march)
    }
}
