package com.mahava.app.cycle

import java.time.LocalDate

/**
 * Finer educational windows scaled to the user's estimated cycle.
 * Ovulation / luteal timing is anchored backward from the next expected period
 * (NHS: ovulation typically ~10–16 days before next period; Bull 2019: mean luteal ~12.4d,
 * follicular length drives most cycle-length variation — never assume fixed day 14).
 */
enum class CycleSubWindow(val id: String, val titleFa: String) {
    MENSTRUATION_EARLY("menstruation_early", "ابتدای خون‌ریزی"),
    MENSTRUATION_LATE("menstruation_late", "ادامه/پایان خون‌ریزی"),
    FOLLICULAR_EARLY("follicular_early", "اوایل فاز فولیکولی تخمینی"),
    FOLLICULAR_LATE("follicular_late", "اواخر فاز فولیکولی تخمینی"),
    PERI_OVULATORY("peri_ovulatory", "نزدیک بازه تخمینی تخمک‌گذاری"),
    LUTEAL_EARLY("luteal_early", "اوایل فاز لوتئال تخمینی"),
    LUTEAL_MID("luteal_mid", "میانه فاز لوتئال تخمینی"),
    LUTEAL_LATE_PREMENSTRUAL("luteal_late_premenstrual", "روزهای پیش از پریود تخمینی"),
    LATE_PERIOD("late_period", "تأخیر نسبت به موعد تخمینی"),
    UNKNOWN("unknown", "مرحله نامشخص")
}

data class CycleDayContext(
    val subWindow: CycleSubWindow,
    val cycleDay: Int?,
    val estimatedCycleLength: Int?,
    val daysUntilCentralPeriod: Int?,
    val daysRelativeToOvulationCentral: Int?,
    val uncertaintyNoteFa: String
)

object CycleDayContextResolver {
    fun resolve(result: CycleEngineResult): CycleDayContext {
        val pred = result.prediction
        val length = when (pred) {
            is PredictionKind.Estimate -> pred.medianCycleLength
            else -> null
        }
        val uncertainty = when {
            result.restriction != PredictionRestriction.NONE ->
                "به‌خاطر محدودیت پیش‌بینی، زیربازه اختصاصی نشان داده نمی‌شود."
            pred is PredictionKind.Estimate && pred.cyclesUsed == 0 ->
                "تخمک‌گذاری نسبت به موعد تخمینی پریود (~۱۴±۳ روز قبل) لنگر شده؛ روز ثابت ۱۴ فرض نشده."
            pred is PredictionKind.Estimate ->
                "بازه‌ها با میانه چرخه‌های ثبت‌شده و عدم‌قطعیت داده ساخته شده‌اند."
            else -> "داده برای زیربازه دقیق کافی نیست."
        }

        if (CycleContentPolicy.forceGeneral(result.restriction) || result.phase == CyclePhase.UNKNOWN && !result.isLate && !result.periodOngoing) {
            return CycleDayContext(CycleSubWindow.UNKNOWN, result.cycleDay, length, result.daysUntilCentralPeriod, null, uncertainty)
        }
        if (result.isLate) {
            return CycleDayContext(CycleSubWindow.LATE_PERIOD, result.cycleDay, length, result.daysUntilCentralPeriod, null, uncertainty)
        }
        if (result.periodOngoing || result.phase == CyclePhase.MENSTRUATION) {
            val bleedDay = result.bleedingDay ?: result.cycleDay
            val sw = if (bleedDay != null && bleedDay <= 2) CycleSubWindow.MENSTRUATION_EARLY else CycleSubWindow.MENSTRUATION_LATE
            return CycleDayContext(sw, result.cycleDay, length, result.daysUntilCentralPeriod, null, uncertainty)
        }
        if (pred !is PredictionKind.Estimate) {
            return CycleDayContext(CycleSubWindow.UNKNOWN, result.cycleDay, length, result.daysUntilCentralPeriod, null, uncertainty)
        }
        val today = result.today
        val ovCentral = pred.ovulationEarliest.plusDays(
            ((pred.ovulationLatest.toEpochDay() - pred.ovulationEarliest.toEpochDay()) / 2)
        )
        val relOv = (today.toEpochDay() - ovCentral.toEpochDay()).toInt()
        val inPeri = !today.isBefore(pred.ovulationEarliest.minusDays(1)) &&
            !today.isAfter(pred.ovulationLatest.plusDays(1))
        if (inPeri) {
            return CycleDayContext(CycleSubWindow.PERI_OVULATORY, result.cycleDay, length, result.daysUntilCentralPeriod, relOv, uncertainty)
        }
        if (today.isBefore(pred.ovulationEarliest)) {
            val last = result.lastPeriodStart
            val mid = if (last != null) {
                val span = (pred.ovulationEarliest.toEpochDay() - last.toEpochDay()).coerceAtLeast(2)
                last.plusDays(span / 2)
            } else null
            val sw = if (mid != null && today.isBefore(mid)) CycleSubWindow.FOLLICULAR_EARLY else CycleSubWindow.FOLLICULAR_LATE
            return CycleDayContext(sw, result.cycleDay, length, result.daysUntilCentralPeriod, relOv, uncertainty)
        }
        // After ovulation estimate → luteal, split by days until period
        val dUntil = result.daysUntilCentralPeriod
        val sw = when {
            dUntil != null && dUntil <= 5 -> CycleSubWindow.LUTEAL_LATE_PREMENSTRUAL
            dUntil != null && dUntil <= 9 -> CycleSubWindow.LUTEAL_MID
            else -> CycleSubWindow.LUTEAL_EARLY
        }
        return CycleDayContext(sw, result.cycleDay, length, dUntil, relOv, uncertainty)
    }
}

object CycleContentPolicy {
    fun forceGeneral(restriction: PredictionRestriction): Boolean =
        restriction in setOf(
            PredictionRestriction.INSUFFICIENT_DATA,
            PredictionRestriction.IRREGULAR,
            PredictionRestriction.HORMONAL_CONTRACEPTION,
            PredictionRestriction.POSTPARTUM_OR_BREASTFEEDING,
            PredictionRestriction.PERIMENOPAUSE,
            PredictionRestriction.PREGNANCY_MODE
        )
}
