package com.mahava.app.ui.screens

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.mahava.app.R
import com.mahava.app.cycle.PredictionKind
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import com.mahava.app.util.JalaliDate
import com.mahava.app.util.PersianDigits
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

@Composable
fun ReportsScreen(vm: AppViewModel, onSettings: () -> Unit, onDoctor: () -> Unit, onLate: () -> Unit) {
    val state by vm.state.collectAsState()
    val periods = state.periods.sortedBy { it.startEpochDay }
    val lengths = periods.zipWithNext { a, b -> (b.startEpochDay - a.startEpochDay).toInt() }.filter { it in 15..90 }
    val bleedLens = periods.mapNotNull { p ->
        val end = p.endEpochDay ?: return@mapNotNull null
        (end - p.startEpochDay + 1).toInt()
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("گزارش‌های من", onSettings = onSettings)
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MahavaCard(Modifier.weight(1f)) {
                MahavaIcon(R.drawable.ic_droplet, MahavaMenstruation)
                Text("میانگین مدت خون‌ریزی", color = MahavaTextSecondary)
                Text(
                    if (bleedLens.isEmpty()) "—" else "${PersianDigits.toPersian(bleedLens.average().toInt())} روز",
                    style = MaterialTheme.typography.headlineLarge
                )
                QuietInfo(if (bleedLens.isEmpty()) "داده کافی نیست" else "بر پایه ${PersianDigits.toPersian(bleedLens.size)} دوره")
            }
            MahavaCard(Modifier.weight(1f)) {
                MahavaIcon(R.drawable.ic_cycle)
                Text("میانگین طول چرخه", color = MahavaTextSecondary)
                Text(
                    if (lengths.isEmpty()) "—" else "${PersianDigits.toPersian(lengths.average().toInt())} روز",
                    style = MaterialTheme.typography.headlineLarge
                )
                QuietInfo(if (lengths.isEmpty()) "داده کافی نیست" else "بر پایه ${PersianDigits.toPersian(lengths.size)} چرخه")
            }
        }
        MahavaCard(Modifier.padding(horizontal = 16.dp)) {
            Text("طول چرخه‌های اخیر", style = MaterialTheme.typography.titleLarge)
            if (lengths.isEmpty()) QuietInfo("هنوز چرخه کامل ثبت نشده. نمودار نمونه نشان داده نمی‌شود.")
            else lengths.takeLast(6).forEachIndexed { idx, len ->
                Text("چرخه ${PersianDigits.toPersian(idx + 1)}: ${PersianDigits.toPersian(len)} روز")
            }
        }
        Spacer(Modifier.height(8.dp))
        MahavaCard(Modifier.padding(horizontal = 16.dp)) {
            Text("الگوی علائم", style = MaterialTheme.typography.titleLarge)
            if (state.patterns.isEmpty()) QuietInfo("برای الگو حداقل ۲ چرخه با ثبت واقعی لازم است.")
            else state.patterns.forEach { Text("• ${it.textFa}") }
        }
        Spacer(Modifier.height(8.dp))
        MahavaCard(Modifier.padding(16.dp).clickable(onClick = onDoctor)) {
            Text("گزارش برای پزشک", style = MaterialTheme.typography.titleMedium)
            QuietInfo("بازه، پیش‌نمایش، حذف بخش‌های خصوصی و اشتراک صریح")
        }
        MahavaCard(Modifier.padding(horizontal = 16.dp).clickable(onClick = onLate)) {
            Text("تأخیر و تست", style = MaterialTheme.typography.titleMedium)
        }
        val pred = state.cycle?.prediction
        if (pred is PredictionKind.Estimate && periods.isNotEmpty()) {
            Text("تخمین قبلی بر پایه الگوریتم ${state.cycle?.algorithmVersion} — مقایسه با شروع واقعی پس از ثبت ممکن است.", modifier = Modifier.padding(16.dp), color = MahavaTextSecondary)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun DoctorReportScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var from by remember { mutableStateOf(vm.today().minusDays(90)) }
    var to by remember { mutableStateOf(vm.today()) }
    var includeNotes by remember { mutableStateOf(false) }
    var includeIntimate by remember { mutableStateOf(false) }
    var includeTests by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf("") }

    fun buildText(): String {
        val sb = StringBuilder()
        sb.appendLine("گزارش ماه‌آوا برای پزشک")
        sb.appendLine("بازه: ${JalaliDate.from(from).formatFa()} تا ${JalaliDate.from(to).formatFa()}")
        sb.appendLine("وضعیت: آموزشی — تشخیص نیست")
        sb.appendLine()
        sb.appendLine("پریودها:")
        state.periods.filter { it.startEpochDay in from.toEpochDay()..to.toEpochDay() }.forEach {
            sb.appendLine("- شروع ${JalaliDate.from(LocalDate.ofEpochDay(it.startEpochDay)).formatFa()} پایان ${it.endEpochDay?.let { d -> JalaliDate.from(LocalDate.ofEpochDay(d)).formatFa() } ?: "ادامه‌دار"}")
        }
        sb.appendLine()
        sb.appendLine("علائم:")
        state.dailyLogs.filter { it.epochDay in from.toEpochDay()..to.toEpochDay() }.forEach { log ->
            if (!includeIntimate && log.intimacyLogged) return@forEach
            sb.append("- ${JalaliDate.from(LocalDate.ofEpochDay(log.epochDay)).formatFa()}: ")
            sb.append("خون‌ریزی=${log.bleeding ?: "-"} درد=${log.painScore ?: "-"} خلق=${log.moods ?: "-"}")
            if (includeNotes) sb.append(" یادداشت=${log.note ?: "-"}")
            if (includeTests) sb.append(" تست بارداری=${log.pregnancyTest ?: "-"}")
            sb.appendLine()
        }
        sb.appendLine()
        sb.appendLine("الگوها:")
        state.patterns.forEach { sb.appendLine("- ${it.textFa}") }
        return sb.toString()
    }

    val shareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
        var y = 40f
        buildText().lines().forEach { line ->
            page.canvas.drawText(line.take(80), 40f, y, paint)
            y += 18f
            if (y > 800) return@forEach
        }
        doc.finishPage(page)
        ctx.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        doc.close()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("گزارش پزشک", onBack = onBack)
        QuietInfo("از ${JalaliDate.from(from).formatFa()} تا ${JalaliDate.from(to).formatFa()}")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceChipPill("۹۰ روز", false, { from = vm.today().minusDays(90); to = vm.today() })
            ChoiceChipPill("۱۸۰ روز", false, { from = vm.today().minusDays(180); to = vm.today() })
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(includeNotes, { includeNotes = it }); Text("یادداشت‌ها")
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(includeIntimate, { includeIntimate = it }); Text("رابطه/موارد خصوصی")
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(includeTests, { includeTests = it }); Text("نتایج تست")
        }
        SecondaryButton("پیش‌نمایش") { preview = buildText() }
        if (preview.isNotBlank()) {
            MahavaCard { Text(preview, style = MaterialTheme.typography.bodySmall) }
        }
        PrimaryButton("ساخت و اشتراک PDF (صریح)") {
            preview = buildText()
            shareLauncher.launch("mahava-doctor-report.pdf")
        }
        QuietInfo("اشتراک فقط با اقدام تو انجام می‌شود. فایل ممکن است اطلاعات خصوصی داشته باشد.")
    }
}

@Composable
fun LateTestScreen(vm: AppViewModel, onBack: () -> Unit, onLogPeriod: () -> Unit) {
    val state by vm.state.collectAsState()
    var result by remember { mutableStateOf<String?>(null) }
    var testDate by remember { mutableStateOf(vm.today()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("تأخیر و تست بارداری", onBack = onBack)
        Illustration(R.drawable.ill_test_guide_woman, Modifier.height(140.dp))
        MahavaCard {
            Text("پریود هنوز ثبت نشده؟", style = MaterialTheme.typography.titleMedium)
            val pred = state.cycle?.prediction
            if (pred is PredictionKind.Estimate) {
                QuietInfo("موعد تخمینی حوالی ${JalaliDate.from(pred.nextPeriodStartCentral).formatFa()}")
            } else QuietInfo("موعد مشخصی محاسبه نشده است.")
            SecondaryButton("شروع شده ولی ثبت نکردی؟", onLogPeriod)
        }
        MahavaCard {
            Text("زمان مناسب تست", style = MaterialTheme.typography.titleMedium)
            QuietInfo("طبق NHS: از روز اول پریود عقب‌افتاده قابل اعتمادتر است. اگر موعد نامشخص است، حدود ۲۱ روز پس از رابطه بدون محافظت.")
            }
        SectionLabel("نتیجه تست (اختیاری)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("invalid" to "نامعتبر", "negative" to "منفی", "positive" to "مثبت").forEach { (k, l) ->
                ChoiceChipPill(l, result == k, { result = k })
            }
        }
        QuietInfo("تاریخ تست: ${JalaliDate.from(testDate).formatFa()}")
        PrimaryButton("ثبت نتیجه") {
            val now = System.currentTimeMillis()
            val existing = vm.logFor(testDate)
            vm.saveDailyLog(
                (existing ?: com.mahava.app.data.db.DailyLogEntity(epochDay = testDate.toEpochDay(), createdAt = now, updatedAt = now)).copy(
                    pregnancyTest = result,
                    pregnancyTestEpochDay = testDate.toEpochDay(),
                    updatedAt = now
                )
            )
            if (result == "positive") {
                vm.updateProfile { it.copy(pregnancyMode = true, fertilityTrackingEnabled = false) }
            }
            onBack()
        }
        QuietInfo("نتیجه منفی زودهنگام قطعی نیست. محتوای آموزشی — توصیه پزشکی نیست. منبع: NHS.")
        SecondaryButton("جلوگیری اضطراری (آموزشی)") { /* opens body item via care */ }
    }
}

// helper to avoid missing drawable compile — no-op height
@Composable
fun CareScreen(vm: AppViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("مراقبت و راهنمای علائم", onBack = onBack)
        Illustration(R.drawable.ill_care_woman, Modifier.height(140.dp))
        MahavaCard {
            Text("برای درد خفیف", style = MaterialTheme.typography.titleMedium, color = MahavaFertility)
            QuietInfo("گرمای ملایم، کیسه آب گرم با محافظ، حرکت سبک. منبع: NHS period pain.")
        }
        MahavaCard {
            Text("نیاز به بررسی", style = MaterialTheme.typography.titleMedium, color = MahavaMenstruation)
            QuietInfo("درد مقاوم به مراقبت معمول، خون‌ریزی خیلی سنگین/طولانی، تغییر ناگهانی شدید چرخه.")
        }
        MahavaCard {
            Text("کمک فوری", style = MaterialTheme.typography.titleMedium, color = MahavaDanger)
            QuietInfo("درد ناگهانی شدید شکم، غش/سرگیجه شدید، خون‌ریزی بسیار زیاد در زمان کوتاه. شماره اورژانس کشور خودت را بگیر — اینجا عددی فرض نشده.")
        }
        QuietInfo("آموزشی است و تشخیص پزشکی نیست.")
    }
}
