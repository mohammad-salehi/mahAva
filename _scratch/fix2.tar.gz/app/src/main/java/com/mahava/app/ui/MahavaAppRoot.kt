package com.mahava.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mahava.app.R
import com.mahava.app.ui.navigation.Routes
import com.mahava.app.ui.screens.*
import com.mahava.app.ui.theme.MahavaPrimary
import com.mahava.app.ui.theme.MahavaSurface
import com.mahava.app.ui.theme.MahavaTextSecondary
import java.time.LocalDate

@Composable
fun MahavaAppRoot(vm: AppViewModel, activity: FragmentActivity) {
    val state by vm.state.collectAsState()
    if (!state.ready) {
        CircularProgressIndicator()
        return
    }
    if (state.locked) {
        LaunchedEffect(Unit) {
            promptUnlock(activity, onOk = { vm.unlock() }, onFail = { })
        }
        Text("برای ادامه قفل را باز کن", modifier = Modifier.padding(24.dp))
        Button(onClick = { promptUnlock(activity, onOk = { vm.unlock() }, onFail = {}) }) { Text("باز کردن") }
        return
    }

    val onboardingDone = state.profile?.onboardingDone == true
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBottom = onboardingDone && route in setOf(Routes.TODAY, Routes.CALENDAR, Routes.LOG_HUB, Routes.REPORTS, Routes.BODY)

    Scaffold(
        bottomBar = {
            if (showBottom) {
                NavigationBar(containerColor = MahavaSurface) {
                    NavItem(nav, Routes.TODAY, "امروز", R.drawable.ic_home, route)
                    NavItem(nav, Routes.CALENDAR, "تقویم", R.drawable.ic_calendar, route)
                    NavItem(nav, Routes.LOG_HUB, "ثبت", R.drawable.ic_plus, route)
                    NavItem(nav, Routes.REPORTS, "گزارش‌ها", R.drawable.ic_reports, route)
                    NavItem(nav, Routes.BODY, "شناخت بدن", R.drawable.ic_leaf, route)
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = if (onboardingDone) Routes.TODAY else Routes.ONBOARDING,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.ONBOARDING) {
                OnboardingFlow(vm) {
                    nav.navigate(Routes.TODAY) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            }
            composable(Routes.TODAY) {
                TodayScreen(
                    vm,
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onDailyLog = { nav.navigate(Routes.dailyLog(vm.today().toEpochDay())) },
                    onPeriod = { nav.navigate(Routes.PERIOD_LOG) },
                    onBody = { nav.navigate(Routes.BODY) },
                    onLate = { nav.navigate(Routes.LATE) }
                )
            }
            composable(Routes.CALENDAR) {
                CalendarScreen(vm, onSettings = { nav.navigate(Routes.SETTINGS) }) { day ->
                    nav.navigate(Routes.dailyLog(day.toEpochDay()))
                }
            }
            composable(Routes.LOG_HUB) {
                LogHubScreen(
                    vm,
                    onDaily = { nav.navigate(Routes.dailyLog(vm.today().toEpochDay())) },
                    onPeriod = { nav.navigate(Routes.PERIOD_LOG) },
                    onSettings = { nav.navigate(Routes.SETTINGS) }
                )
            }
            composable(
                route = "daily_log?day={day}",
                arguments = listOf(navArgument("day") { type = NavType.LongType; defaultValue = -1L })
            ) { entry ->
                val dayArg = entry.arguments?.getLong("day") ?: -1L
                val day = if (dayArg >= 0) LocalDate.ofEpochDay(dayArg) else vm.today()
                DailyLogScreen(vm, day) { nav.popBackStack() }
            }
            composable(Routes.PERIOD_LOG) { PeriodLogScreen(vm) { nav.popBackStack() } }
            composable(Routes.REPORTS) {
                ReportsScreen(
                    vm,
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onDoctor = { nav.navigate(Routes.DOCTOR_PDF) },
                    onLate = { nav.navigate(Routes.LATE) }
                )
            }
            composable(Routes.DOCTOR_PDF) { DoctorReportScreen(vm) { nav.popBackStack() } }
            composable(Routes.BODY) {
                BodyHomeScreen(
                    vm,
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onCategory = { nav.navigate(Routes.bodyCat(it)) },
                    onCare = { nav.navigate(Routes.CARE) }
                )
            }
            composable(
                Routes.BODY_CAT,
                arguments = listOf(navArgument("category") { type = NavType.StringType })
            ) { entry ->
                val cat = entry.arguments?.getString("category") ?: return@composable
                BodyCategoryScreen(vm, cat, onBack = { nav.popBackStack() }) { id ->
                    nav.navigate(Routes.bodyItem(id))
                }
            }
            composable(
                Routes.BODY_ITEM,
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("id") ?: return@composable
                BodyItemScreen(vm, id) { nav.popBackStack() }
            }
            composable(Routes.LATE) {
                LateTestScreen(vm, onBack = { nav.popBackStack() }, onLogPeriod = { nav.navigate(Routes.PERIOD_LOG) })
            }
            composable(Routes.CARE) { CareScreen(vm) { nav.popBackStack() } }
            composable(Routes.SETTINGS) { SettingsScreen(vm, activity) { nav.popBackStack() } }
        }
    }

    state.message?.let { msg ->
        LaunchedEffect(msg) {
            // snackbar-like clear
            kotlinx.coroutines.delay(2500)
            vm.clearMessage()
        }
    }
}

@Composable
private fun NavItem(nav: androidx.navigation.NavHostController, route: String, label: String, icon: Int, current: String?) {
    val selected = current == route
    NavigationBarItem(
        selected = selected,
        onClick = {
            nav.navigate(route) {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        },
        icon = {
            Icon(
                painter = painterResource(icon),
                contentDescription = label,
                tint = if (selected) MahavaPrimary else MahavaTextSecondary
            )
        },
        label = { Text(label, color = if (selected) MahavaPrimary else MahavaTextSecondary) },
        colors = NavigationBarItemDefaults.colors(indicatorColor = Color(0xFFEEE8FB))
    )
}
