package com.mahava.app.content

import com.mahava.app.cycle.CycleContentPolicy
import com.mahava.app.cycle.CycleDayContext
import com.mahava.app.cycle.CyclePhase
import com.mahava.app.cycle.CycleSubWindow
import com.mahava.app.cycle.PredictionRestriction

object PhaseContentSelector {

    fun phaseKey(phase: CyclePhase): String = when (phase) {
        CyclePhase.MENSTRUATION -> "menstruation"
        CyclePhase.FOLLICULAR -> "follicular"
        CyclePhase.OVULATION_WINDOW -> "ovulation"
        CyclePhase.LUTEAL -> "luteal"
        CyclePhase.UNKNOWN -> "unknown"
    }

    fun restrictionNoteFa(restriction: PredictionRestriction): String? = when (restriction) {
        PredictionRestriction.NONE -> null
        PredictionRestriction.INSUFFICIENT_DATA ->
            "داده کافی برای تخمین زیربازه نیست؛ توضیح عمومی نشان داده می‌شود."
        PredictionRestriction.IRREGULAR ->
            "چرخه نامنظم گزارش شده؛ زیربازه اختصاصی نمایش داده نمی‌شود."
        PredictionRestriction.HORMONAL_CONTRACEPTION ->
            "روش هورمونی ثبت شده؛ پیش‌بینی مرحلهٔ تقویمی محدود است."
        PredictionRestriction.POSTPARTUM_OR_BREASTFEEDING ->
            "شرایط پس از زایمان/شیردهی ثبت شده؛ مرحله اختصاصی نشان داده نمی‌شود."
        PredictionRestriction.PERIMENOPAUSE ->
            "پیش‌یائسگی ثبت شده؛ تخمین مرحله محدود است."
        PredictionRestriction.PREGNANCY_MODE ->
            "حالت بارداری فعال است؛ محتوای مرحلهٔ چرخه معمول متوقف شده."
        PredictionRestriction.USER_DISABLED_FERTILITY -> null
    }

    fun selectPhase(bank: ContentBank, ctx: CycleDayContext, restriction: PredictionRestriction): PhaseContentSelection {
        val sw = if (CycleContentPolicy.forceGeneral(restriction)) CycleSubWindow.UNKNOWN else ctx.subWindow
        val id = "sw_${sw.id}"
        val item = bank.items.find { it.id == id }
            ?: bank.items.find { it.id == "sw_unknown" }
            ?: bank.items.first { it.category == BodyCategories.CYCLE_HORMONES }
        val general = sw == CycleSubWindow.UNKNOWN || CycleContentPolicy.forceGeneral(restriction)
        val note = if (general) restrictionNoteFa(restriction)
            ?: if (sw == CycleSubWindow.UNKNOWN) "مرحله/زیربازه امروز نامشخص است." else null
        else null
        return PhaseContentSelection(
            item = item,
            subWindowId = sw.id,
            restrictionNoteFa = note,
            usedGeneralFallback = general,
            uncertaintyNoteFa = ctx.uncertaintyNoteFa
        )
    }

    fun selectCare(bank: ContentBank, ctx: CycleDayContext, restriction: PredictionRestriction, painScore: Int?): ContentItem {
        val sw = if (CycleContentPolicy.forceGeneral(restriction)) CycleSubWindow.UNKNOWN else ctx.subWindow
        var id = "care_sw_${sw.id}"
        // map late_premenstrual naming
        if (sw == CycleSubWindow.LUTEAL_LATE_PREMENSTRUAL) id = "care_sw_luteal_late"
        if (sw == CycleSubWindow.LATE_PERIOD) id = "care_sw_late"
        if (painScore != null && painScore >= 5 && sw in setOf(CycleSubWindow.UNKNOWN, CycleSubWindow.FOLLICULAR_EARLY)) {
            id = "care_sw_menstruation_early"
        }
        return bank.items.find { it.id == id }
            ?: bank.items.find { it.id == "care_sw_unknown" }
            ?: bank.items.first { it.category == BodyCategories.PATTERN_CARE }
    }

    fun matchesSubWindow(item: ContentItem, subWindowId: String): Boolean {
        val rules = item.displayRules.showWhenSubWindow
        return rules.contains("any") || rules.contains(subWindowId)
    }
}
