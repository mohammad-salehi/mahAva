package com.mahava.app.content

data class ContentSource(val title: String, val org: String, val url: String)

data class DisplayRules(
    val showWhenPhase: List<String> = listOf("any"),
    val showWhenSubWindow: List<String> = listOf("any"),
    val hideWhenPregnancyMode: Boolean = false,
    val requiresFertilityEnabled: Boolean = false,
    val minCycleDay: Int? = null,
    val maxCycleDay: Int? = null
)

data class ContentItem(
    val id: String,
    val category: String,
    val titleFa: String,
    val summaryFa: String,
    val bodyFa: String,
    val applicableContexts: List<String>,
    val excludedContexts: List<String>,
    val evidenceType: String,
    val sources: List<ContentSource>,
    val sourceCheckedDate: String,
    val contentVersion: String,
    val medicalReviewStatus: String,
    val displayRules: DisplayRules,
    val whatYouCanDoFa: String? = null,
    val whenToSeekFa: String? = null
)

data class ContentBank(
    val contentVersion: String,
    val sourceCheckedDate: String,
    val medicalReviewStatus: String,
    val notesFa: String?,
    val items: List<ContentItem>
)

data class PhaseContentSelection(
    val item: ContentItem,
    val subWindowId: String,
    val restrictionNoteFa: String? = null,
    val usedGeneralFallback: Boolean = false,
    val uncertaintyNoteFa: String = ""
)

object BodyCategories {
    const val CYCLE_HORMONES = "cycle_hormones"
    const val PERIOD_PAIN = "period_pain"
    const val FERTILITY_DISCHARGE = "fertility_discharge"
    const val SLEEP_MOOD = "sleep_mood"
    const val DIGESTION_SKIN = "digestion_skin"
    const val PATTERN_CARE = "pattern_care"

    val all = listOf(
        CYCLE_HORMONES to "چرخه و هورمون‌ها",
        PERIOD_PAIN to "پریود و درد",
        FERTILITY_DISCHARGE to "باروری و ترشحات",
        SLEEP_MOOD to "خواب و حال روحی",
        DIGESTION_SKIN to "گوارش و پوست",
        PATTERN_CARE to "الگو و مراقبت"
    )
}
