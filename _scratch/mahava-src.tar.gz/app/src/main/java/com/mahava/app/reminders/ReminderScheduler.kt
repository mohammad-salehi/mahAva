package com.mahava.app.reminders

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mahava.app.MainActivity
import com.mahava.app.MahavaApplication
import com.mahava.app.R
import java.util.concurrent.TimeUnit

/**
 * Reminders via WorkManager only — no SCHEDULE_EXACT_ALARM.
 * Notification text is private by default.
 */
class ReminderScheduler(private val context: Context) {
    companion object {
        const val CHANNEL_ID = "mahava_reminders"
        const val WORK_NAME = "mahava_daily_reminder_tick"
    }

    fun ensurePeriodic() {
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(12, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            req
        )
    }

    fun cancelAll() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        NotificationManagerCompat.from(context).cancelAll()
    }

    fun canPostNotifications(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else true
    }
}

class ReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as MahavaApplication
        val reminders = app.database.reminderDao().getAll().filter { it.enabled }
        if (reminders.isEmpty()) return Result.success()
        if (!app.reminderScheduler.canPostNotifications()) return Result.success()

        val profile = app.database.profileDao().get()
        val private = profile?.privateNotifications != false
        val text = if (private) {
            applicationContext.getString(R.string.notification_private_text)
        } else {
            "یادآوری ماه‌آوا"
        }
        val intent = Intent(applicationContext, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(applicationContext, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(applicationContext.getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(applicationContext).notify(1001, notif)
        return Result.success()
    }
}

class BootAndTimeReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val app = context.applicationContext as? MahavaApplication ?: return
        app.reminderScheduler.ensurePeriodic()
    }
}
