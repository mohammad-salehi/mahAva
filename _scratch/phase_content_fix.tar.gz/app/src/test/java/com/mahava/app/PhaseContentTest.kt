package com.mahava.app

import com.google.gson.Gson
import com.mahava.app.content.ContentBank
import com.mahava.app.content.PhaseContentSelector
import com.mahava.app.cycle.CycleDayContext
import com.mahava.app.cycle.CycleDayContextResolver
import com.mahava.app.cycle.CycleEngine
import com.mahava.app.cycle.CycleEngineResult
import com.mahava.app.cycle.CyclePhase
import com.mahava.app.cycle.CycleSubWindow
import com.mahava.app.cycle.PeriodInterval
import com.mahava.app.cycle.PredictionKind
import com.mahava.app.cycle.PredictionRestriction
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PhaseSelectorUnitTest {
    private fun bank(): ContentBank {
        val ctx = RuntimeEnvironment.getApplication()
        val json = ctx.assets.open("content/content_bank.json").bufferedReader().readText()
        return Gson().fromJson(json, ContentBank::class.java)
    }

    @Test fun selectsPeriOvulatoryContent() {
        val b = bank()
        val ctx = CycleDayContext(CycleSubWindow.PERI_OVULATORY, 14, 28, 14, 0, "t")
        val sel = PhaseContentSelector.selectPhase(b, ctx, PredictionRestriction.NONE)
        assertEquals("sw_peri_ovulatory", sel.item.id)
        assertFalse(sel.usedGeneralFallback)
        assertTrue(sel.item.bodyFa.contains("LH") || sel.item.bodyFa.contains("تخمک"))
    }

    @Test fun restrictedUsesGeneral() {
        val b = bank()
        val ctx = CycleDayContext(CycleSubWindow.FOLLICULAR_EARLY, 5, 28, 20, null, "t")
        val sel = PhaseContentSelector.selectPhase(b, ctx, PredictionRestriction.HORMONAL_CONTRACEPTION)
        assertEquals("sw_unknown", sel.item.id)
        assertTrue(sel.usedGeneralFallback)
        assertNotNull(sel.restrictionNoteFa)
    }

    @Test fun irregularUsesGeneral() {
        val b = bank()
        val ctx = CycleDayContext(CycleSubWindow.LUTEAL_MID, 20, 28, 8, null, "t")
        val sel = PhaseContentSelector.selectPhase(b, ctx, PredictionRestriction.IRREGULAR)
        assertTrue(sel.usedGeneralFallback)
        assertEquals("sw_unknown", sel.item.id)
    }

    @Test fun careMatchesWindow() {
        val b = bank()
        val ctx = CycleDayContext(CycleSubWindow.LUTEAL_LATE_PREMENSTRUAL, 25, 28, 3, null, "t")
        val care = PhaseContentSelector.selectCare(b, ctx, PredictionRestriction.NONE, null)
        assertEquals("care_sw_luteal_late", care.id)
    }

    @Test fun noFabricatedReviewInPhaseItems() {
        val b = bank()
        b.items.filter { it.id.startsWith("sw_") }.forEach {
            assertTrue(it.medicalReviewStatus.contains("بازبینی پزشکی مستقل انجام نشده"))
            assertTrue(it.sources.isNotEmpty())
            it.sources.forEach { s -> assertTrue(s.url.startsWith("https://")) }
        }
    }
}

class CycleDayContextTest {
    @Test fun lutealAnchoredNotFixedDay14() {
        val engine = CycleEngine()
        val today = LocalDate.of(2026, 10, 6)
        val start = today.minusDays(20) // cycle day 21
        val r = engine.compute(
            CycleEngine.Input(
                today = today,
                periods = listOf(PeriodInterval(start, start.plusDays(4))),
                typicalCycleLength = 32, // longer cycle → ovulation later than day 14
                typicalBleedLength = 5,
                regularCycles = true,
                fertilityTrackingEnabled = true
            )
        )
        assertTrue(r.prediction is PredictionKind.Estimate)
        val pred = r.prediction as PredictionKind.Estimate
        val ovCentralOffset = (pred.ovulationEarliest.toEpochDay() + pred.ovulationLatest.toEpochDay()) / 2 - start.toEpochDay() + 1
        // For 32d cycle, ov ~ day 18 (32-14), not day 14
        assertTrue("ov day should scale with cycle length, got $ovCentralOffset", ovCentralOffset >= 16)
        val ctx = CycleDayContextResolver.resolve(r)
        assertNotEquals(CycleSubWindow.UNKNOWN, ctx.subWindow)
    }

    @Test fun earlyMensesWindow() {
        val engine = CycleEngine()
        val today = LocalDate.of(2026, 10, 6)
        val r = engine.compute(
            CycleEngine.Input(
                today = today,
                periods = listOf(PeriodInterval(today, null)),
                typicalCycleLength = 28,
                typicalBleedLength = 5,
                regularCycles = true
            )
        )
        assertEquals(CyclePhase.MENSTRUATION, r.phase)
        val ctx = CycleDayContextResolver.resolve(r)
        assertEquals(CycleSubWindow.MENSTRUATION_EARLY, ctx.subWindow)
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PhaseContentRoboTest {
    @Test fun bankLoadsSubwindows() {
        val ctx = RuntimeEnvironment.getApplication()
        val json = ctx.assets.open("content/content_bank.json").bufferedReader().readText()
        val bank = Gson().fromJson(json, ContentBank::class.java)
        assertTrue(bank.items.any { it.id == "sw_peri_ovulatory" })
        assertTrue(bank.contentVersion.startsWith("1.2"))
    }
}
