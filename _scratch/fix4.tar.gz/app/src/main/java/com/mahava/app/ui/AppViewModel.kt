package com.mahava.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahava.app.MahavaApplication
import com.mahava.app.content.ContentItem
import com.mahava.app.content.ContentRepository
import com.mahava.app.cycle.CycleEngineResult
import com.mahava.app.data.backup.BackupManager
import com.mahava.app.data.backup.RestoreResult
import com.mahava.app.data.db.DailyLogEntity
import com.mahava.app.data.db.PeriodEventEntity
import com.mahava.app.data.db.ReminderPrefEntity
import com.mahava.app.data.db.UserProfileEntity
import com.mahava.app.data.repo.MahavaRepository
import com.mahava.app.pattern.PatternInsight
import com.mahava.app.reminders.ReminderScheduler
import com.mahava.app.util.AppClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class AppUiState(
    val ready: Boolean = false,
    val profile: UserProfileEntity? = null,
    val periods: List<PeriodEventEntity> = emptyList(),
    val dailyLogs: List<DailyLogEntity> = emptyList(),
    val cycle: CycleEngineResult? = null,
    val patterns: List<PatternInsight> = emptyList(),
    val reminders: List<ReminderPrefEntity> = emptyList(),
    val message: String? = null,
    val locked: Boolean = false
)

class AppViewModel(
    private val repo: MahavaRepository,
    private val contentRepo: ContentRepository,
    private val backupManager: BackupManager,
    private val clock: AppClock,
    private val reminderScheduler: ReminderScheduler,
    private val app: MahavaApplication
) : ViewModel() {

    private val _message = MutableStateFlow<String?>(null)
    private val _locked = MutableStateFlow(false)

    private data class Core(val profile: UserProfileEntity?, val periods: List<PeriodEventEntity>, val logs: List<DailyLogEntity>, val cycle: CycleEngineResult, val patterns: List<PatternInsight>)
    private val core = combine(
        repo.observeProfile(),
        repo.observePeriods(),
        repo.observeDailyLogs(),
        repo.observeCycleResult(),
        repo.observePatterns()
    ) { profile, periods, logs, cycle, patterns ->
        Core(profile, periods, logs, cycle, patterns)
    }

    val state: StateFlow<AppUiState> = combine(core, repo.observeReminders(), _message, _locked) { c, reminders, message, locked ->
        AppUiState(
            ready = true,
            profile = c.profile,
            periods = c.periods,
            dailyLogs = c.logs,
            cycle = c.cycle,
            patterns = c.patterns,
            reminders = reminders,
            message = message,
            locked = locked
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AppUiState())

    init {
        viewModelScope.launch {
            val p = repo.ensureProfile()
            _locked.value = p.lockEnabled
            reminderScheduler.ensurePeriodic()
        }
    }

    fun clearMessage() { _message.value = null }
    fun unlock() { _locked.value = false }
    fun relockIfNeeded() {
        val p = state.value.profile
        if (p?.lockEnabled == true) _locked.value = true
    }

    fun contentVersion(): String = contentRepo.load().contentVersion
    fun contentStatus(): String = contentRepo.load().medicalReviewStatus
    fun bodyItems(category: String): List<ContentItem> {
        val s = state.value
        val hidden = s.profile?.hiddenBodyCategories?.split(',')?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
        return contentRepo.visibleItems(
            category = category,
            phase = s.cycle?.phase ?: com.mahava.app.cycle.CyclePhase.UNKNOWN,
            pregnancyMode = s.profile?.pregnancyMode == true,
            fertilityEnabled = s.profile?.fertilityTrackingEnabled == true || s.profile?.goal == "ttc",
            cycleDay = s.cycle?.cycleDay,
            hiddenCategories = hidden
        )
    }
    fun allVisibleContent(): List<ContentItem> {
        val s = state.value
        val hidden = s.profile?.hiddenBodyCategories?.split(',')?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
        return contentRepo.visibleItems(
            phase = s.cycle?.phase ?: com.mahava.app.cycle.CyclePhase.UNKNOWN,
            pregnancyMode = s.profile?.pregnancyMode == true,
            fertilityEnabled = s.profile?.fertilityTrackingEnabled == true || s.profile?.goal == "ttc",
            cycleDay = s.cycle?.cycleDay,
            hiddenCategories = hidden
        )
    }
    fun contentItem(id: String) = contentRepo.item(id)

    fun today(): LocalDate = clock.today()

    fun saveOnboarding(profile: UserProfileEntity) = viewModelScope.launch {
        repo.saveProfile(profile.copy(onboardingDone = true))
        profile.lastPeriodStartEpochDay?.let { day ->
            val existing = repo.observePeriods()
            repo.upsertPeriod(
                PeriodEventEntity(
                    startEpochDay = day,
                    endEpochDay = null,
                    stillOngoing = true,
                    createdAt = clock.nowMillis(),
                    updatedAt = clock.nowMillis()
                )
            )
        }
        _message.value = "راه‌اندازی ذخیره شد"
    }

    fun updateProfile(transform: (UserProfileEntity) -> UserProfileEntity) = viewModelScope.launch {
        val cur = repo.ensureProfile()
        repo.saveProfile(transform(cur))
    }

    fun savePeriod(start: LocalDate, end: LocalDate?, ongoing: Boolean, note: String? = null, existingId: Long = 0) =
        viewModelScope.launch {
            try {
                repo.upsertPeriod(
                    PeriodEventEntity(
                        id = existingId,
                        startEpochDay = start.toEpochDay(),
                        endEpochDay = if (ongoing) null else end?.toEpochDay(),
                        stillOngoing = ongoing,
                        note = note,
                        createdAt = clock.nowMillis(),
                        updatedAt = clock.nowMillis()
                    )
                )
                _message.value = "پریود ذخیره شد"
            } catch (t: Throwable) {
                _message.value = "خطای ورودی: ${t.message}"
            }
        }

    fun deletePeriod(id: Long) = viewModelScope.launch {
        repo.deletePeriod(id)
        _message.value = "حذف شد"
    }

    fun saveDailyLog(log: DailyLogEntity) = viewModelScope.launch {
        repo.upsertDailyLog(log)
        _message.value = "روی گوشی ذخیره شد"
    }

    fun logFor(day: LocalDate): DailyLogEntity? =
        state.value.dailyLogs.find { it.epochDay == day.toEpochDay() }

    fun saveReminder(pref: ReminderPrefEntity) = viewModelScope.launch {
        repo.saveReminder(pref)
        reminderScheduler.ensurePeriodic()
    }

    fun deleteAll() = viewModelScope.launch {
        repo.deleteAllData()
        reminderScheduler.cancelAll()
        repo.ensureProfile()
        _message.value = "همه داده‌ها حذف شد"
    }

    suspend fun exportBackup(password: CharArray): ByteArray =
        backupManager.exportEncrypted(password, clock.nowMillis())

    suspend fun restoreBackup(password: CharArray, bytes: ByteArray): RestoreResult =
        backupManager.restoreEncrypted(password, bytes)

    suspend fun exportJson(): String = repo.exportJson()
    suspend fun exportCsv(): String = repo.exportCsv()

    fun writeBytesToUri(uri: Uri, bytes: ByteArray): Boolean {
        return try {
            app.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            true
        } catch (_: Throwable) { false }
    }

    fun readBytesFromUri(uri: Uri): ByteArray? {
        return try {
            app.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (_: Throwable) { null }
    }
}

class AppViewModelFactory(private val app: MahavaApplication) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AppViewModel(
            repo = app.repository,
            contentRepo = app.contentRepository,
            backupManager = app.backupManager,
            clock = app.clock,
            reminderScheduler = app.reminderScheduler,
            app = app
        ) as T
    }
}
