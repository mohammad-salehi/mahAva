package com.mahava.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahava.app.ui.MahavaAppRoot
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.AppViewModelFactory
import com.mahava.app.ui.theme.MahavaBackground
import com.mahava.app.ui.theme.MahavaTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as MahavaApplication
        setContent {
            MahavaTheme {
                Surface(Modifier.fillMaxSize(), color = MahavaBackground) {
                    val factory = remember {
                        AppViewModelFactory(app)
                    }
                    val vm: AppViewModel = viewModel(factory = factory)
                    MahavaAppRoot(vm = vm, activity = this)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh "today" calculations when returning to foreground / after time change.
        (application as MahavaApplication).let { /* clock is live system clock */ }
    }
}
