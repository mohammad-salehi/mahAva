package com.mahava.app

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class DeviceWalkScreenshotTest {

    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private lateinit var device: UiDevice
    private lateinit var publicDir: File

    @Before
    fun setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        publicDir = File("/sdcard/Pictures/mahava_shots")
        publicDir.mkdirs()
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        File(ctx.getExternalFilesDir(null), "mahava_shots").mkdirs()
    }

    private fun shot(name: String) {
        device.waitForIdle(2500)
        Thread.sleep(500)
        publicDir.mkdirs()
        val f1 = File(publicDir, "$name.png")
        val ok1 = device.takeScreenshot(f1)
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val f2 = File(File(ctx.getExternalFilesDir(null), "mahava_shots"), "$name.png")
        f2.parentFile?.mkdirs()
        device.takeScreenshot(f2)
        check(ok1 || f2.exists()) { "screenshot failed for $name" }
    }

    private fun tap(text: String) {
        rule.onNodeWithText(text, substring = true).performClick()
        device.waitForIdle(1800)
        Thread.sleep(350)
    }

    private fun tapFirst(vararg texts: String) {
        var last: Throwable? = null
        for (t in texts) {
            try {
                rule.onNodeWithText(t, substring = true).performClick()
                device.waitForIdle(1800)
                return
            } catch (t0: Throwable) {
                last = t0
            }
        }
        throw AssertionError("None found: ${texts.toList()}", last)
    }

    private fun exists(text: String): Boolean = try {
        rule.onNodeWithText(text, substring = true).fetchSemanticsNode()
        true
    } catch (_: Throwable) {
        false
    }

    @Test
    fun walkAllMainScreens() {
        shot("01_onboarding_welcome")
        tap("شروع کنیم")
        shot("02_onboarding_cycle")
        tap("ادامه")
        shot("03_onboarding_conditions")
        if (exists("منظم")) tap("منظم")
        tapFirst("ادامه", "فعلاً رد")
        shot("04_onboarding_history")
        tap("ورود به برنامه")
        shot("05_today")

        tap("تقویم")
        shot("06_calendar")

        tap("ثبت")
        shot("07_log_hub")
        if (exists("ثبت حال امروز")) {
            tap("ثبت حال امروز")
            shot("08_daily_log")
            if (exists("ندارم")) tap("ندارم")
            if (exists("خوشحال")) tap("خوشحال")
            if (exists("هیچ علامتی ندارم")) tap("هیچ علامتی ندارم")
            if (exists("ذخیره روی گوشی")) tap("ذخیره روی گوشی")
            device.waitForIdle(1500)
        }

        tap("ثبت")
        if (exists("ثبت پریود")) {
            tap("ثبت پریود")
            shot("09_period_log")
            if (exists("ذخیره پریود")) tap("ذخیره پریود")
            device.waitForIdle(1500)
        }

        tap("گزارش")
        shot("10_reports")
        if (exists("تأخیر")) {
            tap("تأخیر")
            shot("11_late_test")
            device.pressBack()
            device.waitForIdle(1000)
        }
        if (exists("پزشک")) {
            tap("پزشک")
            shot("12_doctor_report")
            device.pressBack()
            device.waitForIdle(1000)
        }

        tap("شناخت بدن")
        shot("13_body_home")
        val cats = listOf(
            "پریود و درد" to "14_body_period_pain",
            "چرخه و هورمون" to "15_body_cycle_hormones",
            "خواب و حال" to "16_body_sleep_mood",
            "باروری و ترشح" to "17_body_fertility",
            "گوارش و پوست" to "18_body_digestion",
            "الگو و مراقبت" to "19_body_pattern_care"
        )
        for ((label, shotName) in cats) {
            tap("شناخت بدن")
            device.waitForIdle(800)
            if (exists(label)) {
                tap(label)
                shot(shotName)
                device.pressBack()
                device.waitForIdle(800)
            }
        }

        tap("شناخت بدن")
        if (exists("چرخه و هورمون")) {
            tap("چرخه و هورمون")
            device.waitForIdle(800)
            if (exists("چرخه قاعدگی چیست")) {
                tap("چرخه قاعدگی چیست")
                shot("20_body_detail")
                device.pressBack()
                device.waitForIdle(600)
            }
            device.pressBack()
            device.waitForIdle(600)
        }

        tap("امروز")
        shot("05b_today_after")
        device.click(90, 170)
        device.waitForIdle(1500)
        if (exists("تنظیمات") || exists("حریم") || exists("قفل")) {
            shot("21_settings")
            device.swipe(540, 1800, 540, 700, 25)
            device.waitForIdle(800)
            shot("22_settings_scrolled")
            if (exists("حذف همه")) {
                tap("حذف همه")
                shot("23_settings_delete_confirm")
                if (exists("انصراف")) tap("انصراف")
            }
        } else {
            shot("21_settings_attempt")
        }

        tap("شناخت بدن")
        if (exists("الگو و مراقبت")) {
            tap("الگو و مراقبت")
            shot("24_pattern_care_cat")
            device.pressBack()
        }

        tap("امروز")
        shot("25_today_final")
    }
}
