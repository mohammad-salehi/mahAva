package com.mahava.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.fragment.app.FragmentActivity
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.AppViewModelFactory
import com.mahava.app.ui.MahavaAppRoot
import com.mahava.app.ui.theme.MahavaBackground
import com.mahava.app.ui.theme.MahavaTheme

class MainActivity : FragmentActivity() {
    private val deepLinkState = mutableStateOf<android.net.Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        enableEdgeToEdge()
        deepLinkState.value = intent?.data
        setContent {
            MahavaTheme {
                Surface(Modifier.fillMaxSize(), color = MahavaBackground) {
                    val factory = remember { AppViewModelFactory(application as MahavaApplication) }
                    val vm: AppViewModel = viewModel(factory = factory)
                    val deepLink by deepLinkState
                    MahavaAppRoot(vm = vm, activity = this, deepLink = deepLink)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        deepLinkState.value = intent.data
    }
}
