package com.mahava.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.mahava.app.R
import com.mahava.app.data.backup.RestoreResult
import com.mahava.app.data.db.ReminderPrefEntity
import com.mahava.app.ui.AppViewModel
import com.mahava.app.ui.components.*
import com.mahava.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: AppViewModel, activity: FragmentActivity, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val profile = state.profile
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var password by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val bytes = vm.exportBackup(password.toCharArray())
                val ok = vm.writeBytesToUri(uri, bytes)
                status = if (ok) "پشتیبان ذخیره شد" else "خطا در نوشتن فایل"
            } catch (t: Throwable) {
                status = "خطا: ${t.message}"
            }
        }
    }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val bytes = vm.readBytesFromUri(uri)
            if (bytes == null) { status = "خواندن فایل ناموفق"; return@launch }
            when (val r = vm.restoreBackup(password.toCharArray(), bytes)) {
                RestoreResult.Success -> status = "بازیابی موفق"
                is RestoreResult.Failed -> status = "بازیابی نشد (${r.reason})؛ داده فعلی تغییر نکرد"
            }
        }
    }
    val exportJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch { vm.writeBytesToUri(uri, vm.exportJson().toByteArray(Charsets.UTF_8)); status = "JSON ذخیره شد — ممکن است خصوصی باشد" }
    }
    val exportCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch { vm.writeBytesToUri(uri, vm.exportCsv().toByteArray(Charsets.UTF_8)); status = "CSV ذخیره شد — ممکن است خصوصی باشد" }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("تنظیمات و حریم خصوصی", onBack = onBack)
        Illustration(R.drawable.ill_privacy_shield, Modifier.height(140.dp))
        Text("داده‌ها روی گوشی تو ذخیره می‌شوند", style = MaterialTheme.typography.headlineLarge)
        QuietInfo("این اپ در زمان استفاده به اینترنت وصل نمی‌شود و analytics/حساب کاربری ندارد.")

        SectionLabel("هدف")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("track_period" to "پریود", "body_awareness" to "شناخت بدن", "ttc" to "بارداری").forEach { (k, l) ->
                ChoiceChipPill(l, profile?.goal == k) { vm.updateProfile { it.copy(goal = k, fertilityTrackingEnabled = k == "ttc" || it.fertilityTrackingEnabled) } }
            }
        }

        SectionLabel("تقویم")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceChipPill("شمسی", profile?.calendarType != "gregorian") { vm.updateProfile { it.copy(calendarType = "jalali") } }
            ChoiceChipPill("میلادی", profile?.calendarType == "gregorian") { vm.updateProfile { it.copy(calendarType = "gregorian") } }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            MahavaIcon(R.drawable.ic_fingerprint); Spacer(Modifier.width(8.dp))
            Text("قفل با بیومتریک/اعتبار دستگاه", Modifier.weight(1f))
            Switch(profile?.lockEnabled == true, { enabled ->
                if (enabled) {
                    val bm = BiometricManager.from(ctx)
                    val can = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    )
                    if (can == BiometricManager.BIOMETRIC_SUCCESS) {
                        vm.updateProfile { it.copy(lockEnabled = true) }
                    } else status = "بیومتریک/قفل دستگاه در دسترس نیست"
                } else vm.updateProfile { it.copy(lockEnabled = false) }
            })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            MahavaIcon(R.drawable.ic_bell); Spacer(Modifier.width(8.dp))
            Text("اعلان خصوصی", Modifier.weight(1f))
            Switch(profile?.privateNotifications != false, { v -> vm.updateProfile { it.copy(privateNotifications = v) } })
        }

        SectionLabel("یادآوری‌ها")
        ReminderToggle(vm, "daily_log", "یادآوری ثبت حال", state.reminders) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ReminderToggle(vm, "period", "یادآوری پریود احتمالی", state.reminders) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        QuietInfo("از exact alarm استفاده نمی‌شود؛ زمان تقریبی است.")

        SectionLabel("پشتیبان رمزگذاری‌شده")
        OutlinedTextField(password, { password = it }, label = { Text("گذرواژه پشتیبان") }, modifier = Modifier.fillMaxWidth())
        QuietInfo("KDF: PBKDF2WithHmacSHA256 (120k) + AES-GCM. گذرواژه ذخیره نمی‌شود.")
        SecondaryButton("ذخیره پشتیبان با SAF") { if (password.length >= 6) createBackup.launch("mahava-backup.mahava") else status = "گذرواژه حداقل ۶ کاراکتر" }
        SecondaryButton("بازیابی از فایل") { if (password.length >= 6) openBackup.launch(arrayOf("*/*")) else status = "گذرواژه را وارد کن" }

        SectionLabel("خروجی بدون رمز")
        SecondaryButton("خروجی JSON") { exportJson.launch("mahava-export.json") }
        SecondaryButton("خروجی CSV") { exportCsv.launch("mahava-export.csv") }

        SectionLabel("حذف")
        if (!confirmDelete) {
            SecondaryButton("حذف همه اطلاعات") { confirmDelete = true }
        } else {
            Text("مطمئنی؟ این کار برگشت‌ناپذیر است.", color = MahavaDanger)
            PrimaryButton("بله، همه را حذف کن") { vm.deleteAll(); confirmDelete = false; status = "حذف شد" }
            SecondaryButton("انصراف") { confirmDelete = false }
        }

        SectionLabel("محتوا و منابع")
        QuietInfo("نسخه بانک محتوا: ${vm.contentVersion()}")
        QuietInfo(vm.contentStatus())
        QuietInfo("فونت Vazirmatn (OFL) به‌صورت محلی بسته‌بندی شده است.")

        if (status.isNotBlank()) Text(status, color = MahavaPrimary)
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun ReminderToggle(vm: AppViewModel, id: String, label: String, list: List<ReminderPrefEntity>, onEnable: () -> Unit) {
    val cur = list.find { it.id == id }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(cur?.enabled == true, { enabled ->
            if (enabled) onEnable()
            vm.saveReminder(ReminderPrefEntity(id = id, enabled = enabled, hour = 9, minute = 0))
        })
    }
}

fun promptUnlock(activity: FragmentActivity, onOk: () -> Unit, onFail: () -> Unit) {
    val executor = ContextCompat.getMainExecutor(activity)
    val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFail() }
        override fun onAuthenticationFailed() { onFail() }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(activity.getString(R.string.lock_title))
        .setSubtitle(activity.getString(R.string.lock_subtitle))
        .setAllowedAuthenticators(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        .build()
    prompt.authenticate(info)
}
